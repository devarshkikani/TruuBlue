import 'MessageData.dart';
import 'User.dart';

class ChatModel {
  List<MessageData> message = [];
  List<User> members = [];
}
