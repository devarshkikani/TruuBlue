import 'dart:io';

import 'package:dating/constants.dart';
import 'package:dating/model/HomeConversationModel.dart';
import 'package:dating/model/User.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/chat/ChatScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';

class MessagesScreen extends StatefulWidget {
  final User user;
  const MessagesScreen({Key? key, required this.user}) : super(key: key);

  @override
  _MessagesScreenState createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  late User user;
  final fireStoreUtils = FireStoreUtils();
  late Stream<List<HomeConversationModel>> _conversationsStream;

  @override
  void initState() {
    super.initState();
    user = widget.user;
    fireStoreUtils.getBlocks().listen((shouldRefresh) {
      if (shouldRefresh) {
        setState(() {});
      }
    });
    _conversationsStream = fireStoreUtils.getConversations(user.userID);
  }
  @override
  Widget build(BuildContext context) {
    return  StreamBuilder<List<HomeConversationModel>>(
      stream: _conversationsStream,
      initialData: [],
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: Center(
              child: CircularProgressIndicator.adaptive(
                valueColor:
                AlwaysStoppedAnimation<Color>(Color(COLOR_ACCENT)),
              ),
            ),
          );
        } else if (!snapshot.hasData ||
            (snapshot.data?.isEmpty ?? true)) {
          return SizedBox(
              width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height-200,
        child:Center(
            child: Text(
              'No Conversations found.'.tr(),
              style: TextStyle(fontSize: 18),
            ),
          ));
        } else {
          return Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final homeConversationModel = snapshot.data![index];
                  if (homeConversationModel.isGroupChat) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 16.0, right: 16, top: 8, bottom: 8),
                      child: _buildConversationRow(homeConversationModel),
                    );
                  } else {
                    return fireStoreUtils.validateIfUserBlocked(
                        homeConversationModel.members.first.userID)
                        ? Container(
                      width: 0,
                      height: 0,
                    )
                        : Padding(
                      padding: const EdgeInsets.only(
                          left: 16.0, right: 16, top: 8, bottom: 8),
                      child: _buildConversationRow(
                          homeConversationModel),
                    );
                  }
                }),
          );
        }
      },
    );
  }

  Widget _buildConversationRow(HomeConversationModel homeConversationModel) {
    String user1Image = '';
    String user2Image = '';
    if (homeConversationModel.members.length >= 2) {
      user1Image = homeConversationModel.members.first.profilePictureURL;
      user2Image = homeConversationModel.members.elementAt(1).profilePictureURL;
    }
    return homeConversationModel.isGroupChat
        ? Padding(
      padding: const EdgeInsets.only(left: 16.0, bottom: 12.8),
      child: InkWell(
        onTap: () {
          push(context,
              ChatScreen(homeConversationModel: homeConversationModel));
        },
        child: Column(
          children: [
            Row(
              children: <Widget>[
                Stack(
                  clipBehavior: Clip.none,
                  children: <Widget>[
                    displayCircleImage(user1Image, 44, false),
                    Positioned(
                        left: -16,
                        bottom: -12.8,
                        child: displayCircleImage(user2Image, 44, true))
                  ],
                ),
                Expanded(
                  child: Padding(
                    padding:
                    const EdgeInsets.only(top: 8, right: 8, left: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${homeConversationModel.conversationModel!.name}',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                fontSize: 20,
                                color: isDarkMode(context)
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '${formatTimestamp(homeConversationModel.conversationModel!.lastMessageDate.seconds)}',
                              maxLines: 1,
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  fontSize: 16, color: Color(0xff000000)),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            '${homeConversationModel.conversationModel!.lastMessage}}',
                            maxLines: 1,
                            textScaleFactor: 1.0,
                            style: TextStyle(
                                fontSize: 16, color: Color(0xff000000)),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
      Padding(
        padding: const EdgeInsets.only(top: 10.0),
        child: Divider(color: Color(0xff000000) ,height: 1,),)
          ],
        ),
      ),
    )
        : InkWell(
      onTap: () {
        push(context,
            ChatScreen(homeConversationModel: homeConversationModel));
      },
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Row(
              children: <Widget>[
                Stack(
                  alignment: Alignment.bottomRight,
                  children: <Widget>[
                    displayCircleImage(
                        homeConversationModel.members.first.profilePictureURL,
                        50,
                        false),
                    Positioned(
                        right: 2.4,
                        bottom: 2.4,
                        child: Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                              color: homeConversationModel.members.first.active
                                  ? Colors.green
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(100),
                              border: Border.all(
                                  color: isDarkMode(context)
                                      ? Color(0xFF303030)
                                      : Colors.white,
                                  width: 1.6)),
                        ))
                  ],
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8, right: 8, left: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${homeConversationModel.members.first.fullName()}',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  fontSize: 20,
                                  color: isDarkMode(context)
                                      ? Colors.white
                                      : Colors.black,fontWeight: FontWeight.bold),
                            ),Text(
                              '${formatTimestamp(homeConversationModel.conversationModel?.lastMessageDate.seconds ?? 0)}',
                              maxLines: 1,
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  fontSize: 16, color: Color(0xff000000)),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 5.0),
                          child: Text(
                            '${homeConversationModel.conversationModel?.lastMessage} ',
                            textScaleFactor: 1.0,
                            maxLines: 1,
                            style: TextStyle(
                                fontSize: 16, color: Color(0xff000000)),
                          ),
                        ),

                      ],
                    ),
                  ),
                )
              ],
            ),
          ),Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Divider(color: Color(0xff000000) ,height: 1,),
          )
        ],
      ),
    );
  }
}
