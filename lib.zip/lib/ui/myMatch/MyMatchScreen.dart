import 'package:dating/constants.dart';
import 'package:dating/ui/myMatch/ActiveMatchesScreen.dart';
import 'package:dating/ui/myMatch/ExpireMatchsScreen.dart';
import 'package:dating/ui/myMatch/MessagesScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:dating/model/User.dart';


class MyMatchScreen extends StatefulWidget {
  final User user;
   MyMatchScreen({Key? key, required this.user}) : super(key: key);

  @override
  State createState() {
    return _MyMatchScreenState();
  }
}

class _MyMatchScreenState extends State<MyMatchScreen> {
  late User user;
  var select=1;
  late Widget _currentWidget;

  @override
  void initState() {
    super.initState();
    user=widget.user;
    _currentWidget=ActiveMatchesScreen(user: user,);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 15,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: (){
                setState(() {
                  select=1;
                  _currentWidget=ActiveMatchesScreen(user: user,);
                });
              },
              child: Text(
                'Active Matches'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(fontSize: 18,color:select==1?Color(COLOR_BLUE_BUTTON): Color(0xFF949494),decoration: TextDecoration.underline),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8.0,left: 8.0),
              child: Container(
                height: 15,
                width: 1,
                color: Color(COLOR_BLUE_BUTTON),
              ),
            ),
            GestureDetector(
              onTap: (){
                setState(() {
                  select=2;
                  _currentWidget=MessagesScreen(user: user,);
                });
              },
              child: Text(
                'Messages'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(fontSize: 18,color:select==2?Color(COLOR_BLUE_BUTTON): Color(0xFF949494),decoration: TextDecoration.underline),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8.0,left: 8.0),
              child: Container(
                height: 15,
                width: 1,
                color: Color(COLOR_BLUE_BUTTON),
              ),
            ),
            GestureDetector(
              onTap: (){
                setState(() {
                  select=3;
                  _currentWidget=ExpireMatchsScreen(user: user,);
                });
              },
              child: Text(
                'Expire Matches'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(fontSize: 18,color:select==3?Color(COLOR_BLUE_BUTTON): Color(0xFF949494),decoration: TextDecoration.underline),
              ),
            )
          ],
        ),
        SafeArea(child:Container(height: MediaQuery.of(context).size.height-190,child: _currentWidget))
      ],
    );
  }
}
