import 'package:cached_network_image/cached_network_image.dart';
import 'package:dating/model/User.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/userDetailsScreen/UserDetailsScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constants.dart';

class LikesScreen extends StatefulWidget {
  final User user;
  const LikesScreen({Key? key, required this.user}) : super(key: key);

  @override
  _LikesScreenState createState() => _LikesScreenState();
}

class _LikesScreenState extends State<LikesScreen> {
  late User user;
  var select=1;
  late Widget _currentWidget;

  @override
  void initState() {
    super.initState();
    user=widget.user;
    _currentWidget=LikesYou(user: user,);
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 15,),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: (){
                setState(() {
                  select=1;
                  _currentWidget=LikesYou(user: user,);
                });
              },
              child: Text(
                'Liked You'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(fontSize: 18,color:select==1?Color(COLOR_BLUE_BUTTON): Color(0xFF949494),decoration: TextDecoration.underline),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8.0,left: 8.0),
              child: Container(
                height: 15,
                width: 1,
                color: Color(COLOR_BLUE_BUTTON),
              ),
            ),
            GestureDetector(
              onTap: (){
                setState(() {
                  select=2;
                  _currentWidget=YouLiked(user: user,);
                });
              },
              child: Text(
                'You Liked'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(fontSize: 18,color:select==2?Color(COLOR_BLUE_BUTTON): Color(0xFF949494),decoration: TextDecoration.underline),
              ),
            )
          ],
        ),
        SafeArea(child: Container(height: MediaQuery.of(context).size.height-190,child: _currentWidget))
      ],
    );
  }
}

class LikesYou extends StatefulWidget {
  final User user;
  const LikesYou({Key? key, required this.user}) : super(key: key);

  @override
  _ActiveLikesState createState() => _ActiveLikesState();
}

class _ActiveLikesState extends State<LikesYou> {
  late User user;
  final fireStoreUtils = FireStoreUtils();
  late Future<List<User>> _matchesFuture;
  @override
  void initState() {
    super.initState();
    user = widget.user;
    fireStoreUtils.getBlocks().listen((shouldRefresh) {
      if (shouldRefresh) {
        setState(() {});
      }
    });
    _matchesFuture = fireStoreUtils.getOtherYouLikedObject(user.userID);
  }
  @override
  Widget build(BuildContext context) {
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    final orientation = MediaQuery.of(context).orientation;
    return FutureBuilder<List<User>>(
      future: _matchesFuture,
      initialData: [],
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting)
          return Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: Center(
              child: CircularProgressIndicator.adaptive(
                valueColor:
                AlwaysStoppedAnimation<Color>(Color(COLOR_ACCENT)),
              ),
            ),
          );
        if (!snap.hasData || (snap.data?.isEmpty ?? true)) {
          return SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: Center(
              child: Text(
                'No Likes found.'.tr(),
                style: TextStyle(fontSize: 18),
              ),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
            child: GridView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.only(
                  bottom: 250),
              itemCount: snap.data!.length,
              itemBuilder: (BuildContext context, int index) {
                User friend = snap.data![index];
                return fireStoreUtils.validateIfUserBlocked(friend.userID)
                    ? Container(
                  width: 0,
                  height: 0,
                )
                    : Padding(
                  padding: const EdgeInsets.only(
                      top: 4.0, left: 0, right: 0,bottom: 4),
                  child: Card(
                    child: Stack(
                      children: <Widget>[
                        Container(
                          child: Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(0),
                              child: CachedNetworkImage(
                                width: scrWidth/2,
                                height: 300,
                                fit: BoxFit.cover,
                                imageUrl: friend.profilePictureURL == DEFAULT_AVATAR_URL
                                    ? ''
                                    : friend.profilePictureURL,
                                placeholder: (context, imageUrl) {
                                  return Icon(
                                    Icons.account_circle,
                                    size: MediaQuery.of(context).size.height * .4,
                                    color:
                                    isDarkMode(context) ? Colors.black : Colors.white,
                                  );
                                },
                                errorWidget: (context, imageUrl, error) {
                                  return Icon(
                                    Icons.account_circle,
                                    size: MediaQuery.of(context).size.height * .4,
                                    color:
                                    isDarkMode(context) ? Colors.black : Colors.white,
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius.vertical(bottom: Radius.circular(0)),
                                gradient: const LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [Colors.black54, Colors.black26])),
                            child: Padding(
                              padding: const EdgeInsets.only(top: 16.0,bottom: 5.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                verticalDirection: VerticalDirection.down,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(top:10,left: 10.0,right: 10.0),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            // controller.triggerRight();
                                            friend.otherLike?
                                            setState(() {
                                            }):setState(() {
                                              fireStoreUtils.otherLikeYouLike(user.userID,friend.userID);
                                              friend.otherLike=true;
                                            });
                                          },
                                          child:friend.otherLike?Icon(
                                            Icons.favorite_rounded,
                                            color: Colors.green,
                                            size: 30,
                                            ) : Icon(
                                            Icons.favorite_border,
                                            color: Colors.white,
                                            size: 30,
                                          ),
                                        ),
                                        InkWell(
                                          onTap: (){
                                            push(
                                                context,
                                                UserDetailsScreen(
                                                  user: friend,
                                                  isMatch: true,
                                                  isMenuVisible: false,
                                                ));
                                          },
                                          child:  Text(
                                                    '${friend.fullName()}',
                                              overflow: TextOverflow.ellipsis,
                                              softWrap: true,
                                                textScaleFactor: 1.0,
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                ),
                                              ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            //controller.triggerLeft();
                                            setState(() {
                                              fireStoreUtils.removeLikeYou(user.userID,friend.userID);
                                              snap.data?.removeAt(index);
                                            });
                                          },
                                          child: Icon(
                                            Icons.close,
                                            color: Colors.white,
                                            size: 30,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    shape: RoundedRectangleBorder(
                      side: BorderSide.none,
                      borderRadius: BorderRadius.circular(0),
                    ),
                    color: Color(COLOR_PRIMARY),
                  ),
                );
              }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(childAspectRatio: 0.7,
                crossAxisCount: (orientation == Orientation.portrait) ? 2 : 3),
            ),
          );
        }
      },
    );
  }
  _onMatchLongPress(User friend) {
    final action = CupertinoActionSheet(
      message: Text(
        friend.fullName(),
        style: TextStyle(fontSize: 15.0),
      ),
      actions: <Widget>[
        CupertinoActionSheetAction(
          child: Text('View Profile'.tr()),
          isDefaultAction: true,
          onPressed: () async {
            Navigator.pop(context);
            push(
                context,
                UserDetailsScreen(
                  user: friend,
                  isMatch: true,
                  isMenuVisible: false,
                ));
          },
        ),
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text(
          'Cancel'.tr(),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );
    showCupertinoModalPopup(context: context, builder: (context) => action);
  }
}

class YouLiked extends StatefulWidget {
  final User user;
  const YouLiked({Key? key, required this.user}) : super(key: key);

  @override
  _YouLikedState createState() => _YouLikedState();
}

class _YouLikedState extends State<YouLiked> {
  late User user;
  final fireStoreUtils = FireStoreUtils();
  late Future<List<User>> _matchesFuture;
  @override
  void initState() {
    super.initState();
    user = widget.user;
    fireStoreUtils.getBlocks().listen((shouldRefresh) {
      if (shouldRefresh) {
        setState(() {});
      }
    });
    _matchesFuture = fireStoreUtils.getYouLikedObject(user.userID);
  }
  @override
  Widget build(BuildContext context) {
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    final orientation = MediaQuery.of(context).orientation;
    return FutureBuilder<List<User>>(
      future: _matchesFuture,
      initialData: [],
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting)
          return Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: Center(
              child: CircularProgressIndicator.adaptive(
                valueColor:
                AlwaysStoppedAnimation<Color>(Color(COLOR_ACCENT)),
              ),
            ),
          );
        if (!snap.hasData || (snap.data?.isEmpty ?? true)) {
          return SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height-200,
            child: Center(
              child: Text(
                'No Likes found.'.tr(),
                style: TextStyle(fontSize: 18),
              ),
            ),
          );
        } else {
          return Padding(
            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
            child: GridView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.only(
                 bottom: 250),
              itemCount: snap.data!.length,
              itemBuilder: (BuildContext context, int index) {
                User friend = snap.data![index];
                return fireStoreUtils.validateIfUserBlocked(friend.userID)
                    ? Container(
                  width: 0,
                  height: 0,
                )
                    : Padding(
                  padding: const EdgeInsets.only(
                      top: 4.0, left: 0, right: 0,bottom: 4),
                  child: Card(
                    child: Stack(
                      children: <Widget>[
                        Container(
                          child: Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(0),
                              child: CachedNetworkImage(
                                width: scrWidth/2,
                                height: 300,
                                fit: BoxFit.cover,
                                imageUrl: friend.profilePictureURL == DEFAULT_AVATAR_URL
                                    ? ''
                                    : friend.profilePictureURL,
                                placeholder: (context, imageUrl) {
                                  return Icon(
                                    Icons.account_circle,
                                    size: MediaQuery.of(context).size.height * .4,
                                    color:
                                    isDarkMode(context) ? Colors.black : Colors.white,
                                  );
                                },
                                errorWidget: (context, imageUrl, error) {
                                  return Icon(
                                    Icons.account_circle,
                                    size: MediaQuery.of(context).size.height * .4,
                                    color:
                                    isDarkMode(context) ? Colors.black : Colors.white,
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius.vertical(bottom: Radius.circular(0)),
                                gradient: const LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [Colors.black54, Colors.black26])),
                            child: Padding(
                              padding: const EdgeInsets.only(top: 16.0,bottom: 5.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                verticalDirection: VerticalDirection.down,
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(top:10,left: 10.0,right: 10.0),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            // controller.triggerRight();
                                            setState(() {
                                              fireStoreUtils.ultraLikeYouLike(user.userID,friend.userID);
                                              friend.ultraLike=true;
                                            });
                                          },
                                          child:friend.ultraLike? ImageIcon(AssetImage('assets/images/thunder_green.png'),color: Colors.green,
                                            size: 30,): ImageIcon(AssetImage('assets/images/thunder.png'), color: Colors.white,
                                            size: 30,),
                                        ),
                                        InkWell(
                                          onTap: (){
                                            push(
                                                context,
                                                UserDetailsScreen(
                                                  user: friend,
                                                  isMatch: true,
                                                  isMenuVisible: false,
                                                ));
                                          },
                                          child:   Text(
                                                '${friend.fullName()}',
                                              overflow: TextOverflow.ellipsis,
                                              softWrap: true,
                                              textScaleFactor: 1.0,
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                ),
                                              ),

                                        ),
                                        InkWell(
                                          onTap: () {
                                            //controller.triggerLeft();
                                            setState(() {
                                              fireStoreUtils.removeYouLike(user.userID,friend.userID);
                                              snap.data?.removeAt(index);
                                            });
                                          },
                                          child: Icon(
                                            Icons.close,
                                            color: Colors.white,
                                            size: 30,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    shape: RoundedRectangleBorder(
                      side: BorderSide.none,
                      borderRadius: BorderRadius.circular(0),
                    ),
                    color: Color(COLOR_PRIMARY),
                  ),
                );
              }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(childAspectRatio: 0.7,
                crossAxisCount: (orientation == Orientation.portrait) ? 2 : 3),
            ),
          );
        }
      },
    );
  }
  _onMatchLongPress(User friend) {
    final action = CupertinoActionSheet(
      message: Text(
        friend.fullName(),
        style: TextStyle(fontSize: 15.0),
      ),
      actions: <Widget>[
        CupertinoActionSheetAction(
          child: Text('View Profile'.tr()),
          isDefaultAction: true,
          onPressed: () async {
            Navigator.pop(context);
            push(
                context,
                UserDetailsScreen(
                  user: friend,
                  isMatch: true,
                  isMenuVisible: false,
                ));
          },
        ),
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text(
          'Cancel'.tr(),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );
    showCupertinoModalPopup(context: context, builder: (context) => action);
  }
}


