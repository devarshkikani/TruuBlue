import 'package:dating/ui/SwipeScreen/SwipeScreen.dart';
import 'package:dating/ui/likes/LikesScreen.dart';
import 'package:dating/ui/myMatch/MessagesScreen.dart';
import 'package:dating/ui/myMatch/MyMatchScreen.dart';
import 'package:flutter/material.dart';
import 'package:dating/model/User.dart';


class HomeBottomNavScreen extends StatefulWidget {
  final User user;
  HomeBottomNavScreen({Key? key, required this.user}) : super(key: key);

  @override
  _HomeBottomNavScreenState createState() => _HomeBottomNavScreenState();
}

class _HomeBottomNavScreenState extends State<HomeBottomNavScreen> {
  int _selectedIndex = 0;
  late User user;
  late List<Widget> _widgetOptions ;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  void initState() {
    super.initState();
    user=widget.user;
    _widgetOptions = <Widget>[
      SwipeScreen(),
      LikesScreen(user: user,),
    MyMatchScreen(user: user, ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              label: "Feed",
                icon: ImageIcon( AssetImage("assets/images/app_circle_icon_one.png")),
            ),
            BottomNavigationBarItem(
              label: "Likes",
                icon:Icon(Icons.favorite),
            ),
            BottomNavigationBarItem(
              label: "Activity",
              icon: ImageIcon( AssetImage("assets/images/match_icon.png")),
            ),
          ],
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.green,
          unselectedItemColor: Color(0XFF6f6f6f),
          iconSize: 40,
          onTap: _onItemTapped,
          elevation: 5
      ),
    );
  }
}
