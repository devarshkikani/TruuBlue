import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:dating/constants.dart';
import 'package:dating/main.dart';
import 'package:dating/model/User.dart' as us;
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/auth/AuthScreen.dart';
import 'package:dating/ui/reauthScreen/reauth_user_screen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart' as auth;



class ProfileSettingsScreen extends StatefulWidget {
  final us.User user;

  const ProfileSettingsScreen({Key? key, required this.user}) : super(key: key);

  @override
  _ProfileSettingsScreenState createState() => _ProfileSettingsScreenState();
}

class _ProfileSettingsScreenState extends State<ProfileSettingsScreen> {
  late us.User user;
  late Widget _currentWidget;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String? verificationId;
  int? emailOTP;
  var notificationNewLkeFlag=false;
  var newLike=false;
  var notificationNewMatchFlag=false;
  var newMatch=false;
  var notificationNewMessageFlag=false;
  var newMessage=false;
  var notificationNewFeaturesFlag=false;
  var newFeatures=false;
  var notificationOffersNewsFlag=false;
  var newOffersNews=false;
  GlobalKey<_ProfileSettingsScreenState> _myKey = GlobalKey();

  @override
  void initState() {
    user = widget.user;
    newLike=user.settings.pushSuperLikesEnabled;
    newMatch=user.settings.pushNewMatchesEnabled;
    newMessage=user.settings.pushNewMessages;
    newFeatures=user.settings.pushFeaturesUpdatesEnabled;
    newOffersNews=user.settings.pushOffersNewsEnabled;
    _currentWidget=_profileHome();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height-117,
      child: Scaffold(
          body: SingleChildScrollView(
              child: _currentWidget)),
    );
  }

  _profileHome(){
    return Padding(
      padding: const EdgeInsets.only(left: 20.0,right: 20.0),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 16.0, left: 32, right: 32),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: <Widget>[
                  Center(
                      child:
                      displayCircleImage(user.profilePictureURL, 100, false)),
                  Positioned(
                    left: 80,
                    right: 80,
                    child: Container(
                      width: 150,
                      decoration: BoxDecoration(
                          color: Color(COLOR_BLUE_BUTTON),
                          borderRadius: BorderRadius.circular(5),
                          shape: BoxShape.rectangle,
                          border: Border.all(color: Color(COLOR_BLUE_BUTTON))),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 2.0,bottom: 2.0),
                        child: Text(
                          '60% Complete'.tr(),
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFFFFFFFF),
                              fontWeight: FontWeight.bold,
                              fontSize: 15),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ), SizedBox(height: 50,),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            InkWell(
              onTap: (){
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              child: Padding(
                padding: const EdgeInsets.only(top: 8.0,bottom: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Account'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                          color: Color(0xFF949494),
                          fontWeight: FontWeight.bold,
                          fontSize: 14),
                      textAlign: TextAlign.start,
                    ),
                    Row(
                      children: [Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                      ],
                    )
                  ],),
              ),
            ),  Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 8.0,bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Dating Tips'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontWeight: FontWeight.bold,
                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Row(
                    children: [Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xFF949494),
                    ),
                    ],
                  )
                ],),

            ),Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 8.0,bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Legal Information'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontWeight: FontWeight.bold,
                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Row(
                    children: [Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xFF949494),
                    ),
                    ],
                  )
                ],),

            ),Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 8.0,bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Help Center'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontWeight: FontWeight.bold,
                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Row(
                    children: [Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xFF949494),
                    ),
                    ],
                  )
                ],),

            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
          ]),
    );
  }

  _AccountInformaton(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
    child: Column(
      children: [
        SizedBox(height: 20,),
        MaterialButton(
          onPressed: () {
            setState(() {
              _currentWidget=_profileHome();
            });
          },
          textColor: Colors.green,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                Icons.arrow_back_ios,
                size: 30,
                color: Color(0xFF0573ac),
              ),
              InkWell(
                onTap: (){

                },
                child: Center(
                  child: Text(
                    'Account Information'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                      color: Color(0xFF7b7b7b),
                      fontWeight: FontWeight.bold,
                      fontSize: 22,),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Icon(
                Icons.arrow_back_ios,
                size: 30,
                color: Color(0x573ac),
              ),
            ],
          ),
          padding: EdgeInsets.all(10),
          shape: CircleBorder(),
        ),

        SizedBox(height: 30,),

        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Phone'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    user.phoneNumber,
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              InkWell(
                onTap: (){
                  setState(() {
                    _currentWidget=_Phone();
                  });
                },
                child: Row(
                  children: [
                    Text(
                      'Edit',
                      textScaleFactor: 1.0,
                      style: TextStyle(
                          color: Color(0xFF949494),
                          fontSize: 14),
                      textAlign: TextAlign.start,
                    ), SizedBox(width: 10,),Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xFF949494),
                    ),
                  ],
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Email'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    user.email,
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: (){
                    setState(() {
                      _currentWidget=_Email();
                    });
                  },
                  child: Row(
                    children: [
                      Text(
                        'Edit',
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ), SizedBox(width: 10,),Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                    ],
                  ),
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Push Notification'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    "On",
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: (){
                    setState(() {
                      _currentWidget=_pushNotification();
                    });
                  },
                  child: Row(
                    children: [
                      Text(
                        'Edit',
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ), SizedBox(width: 10,),Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                    ],
                  ),
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Email Notification'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    'On',
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: (){
                    setState(() {
                    //  _currentWidget=_pushNotification();
                    });
                  },
                  child: Row(
                    children: [
                      Text(
                        'Edit',
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ), SizedBox(width: 10,),Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                    ],
                  ),
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Upgrade Account Features'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    "Current Plan: FREE ACCOUNT",
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: Row(
                  children: [
                    Text(
                      'Upgrade',
                      textScaleFactor: 1.0,
                      style: TextStyle(
                          color: Color(0xFF949494),
                          fontSize: 14),
                      textAlign: TextAlign.start,
                    ), SizedBox(width: 10,),Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                      color: Color(0xFF949494),
                    ),
                  ],
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pause Account'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    "Saves All Matches & Message",
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: (){
                    setState(() {
                      _currentWidget=_pauseAccount();
                    });
                  },
                  child: Row(
                    children: [
                      Text(
                        'Edit',
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ), SizedBox(width: 10,),Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                    ],
                  ),
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
        Padding(
          padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Delete Account'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),

                        fontSize: 14),
                    textAlign: TextAlign.start,
                  ),
                  Text(
                    'Delete Account and All Data',
                    textScaleFactor: 1.0,
                    style: TextStyle(
                        color: Color(0xFF949494),
                        fontSize: 12),
                    textAlign: TextAlign.start,
                  ),
                ],
              ),
              Align(
                alignment: Alignment.topRight,
                child: InkWell(
                  onTap: (){
                    setState(() {
                      _currentWidget=_deleteAccount();
                    });
                  },
                  child: Row(
                    children: [
                      Text(
                        'Edit',
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ), SizedBox(width: 10,),Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                        color: Color(0xFF949494),
                      ),
                    ],
                  ),
                ),
              )
            ],),
        ),
        Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
      ],)
    );
  }

  _Phone(){
      return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Phone Update'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x494949),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 30,),

            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Phone'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),
                      Text(
                        user.phoneNumber,
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setState(() {
                        _currentWidget=_cellNumber();
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Update',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            SizedBox(height: 30,),
            Text(
              'You can update your phone number once. Click the Update link above, enter your new cell number, and well send you a new code to verify your account.',
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xFF949494),
                  fontSize: 12),
              textAlign: TextAlign.start,
            ),
          ],)
    );
  }

  PhoneNumber? phone;
  _cellNumber(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_Phone();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Enter Your Cell Number'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x494949),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 30,),

            Padding(
              padding: const EdgeInsets.only(
                  top: 32.0, right: 8.0, left: 8.0),
              child: Container(
                color: Colors.white,
                child: IntlPhoneField(
                  decoration: InputDecoration(
                    labelText: 'Cell Number'.tr(),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(),
                    ),
                  ),
                  initialCountryCode: 'US',
                  onChanged: (pho) {
                    if (pho.number.length == 10) {
                      FocusScope.of(context)
                          .requestFocus(FocusNode());
                    }
                    phone = pho;
                  },
                ),
              ),
            ),
             Row(
               mainAxisAlignment: MainAxisAlignment.end,
               children: [
                  MaterialButton(
                      onPressed: () async {
                        if (phone != null) {
                          if (phone!.number.length >= 10) {
                            //await _submitPhoneNumber(_phoneNumber!);
                            bool? user = await FireStoreUtils.getCellNumber(
                                (phone!.countryCode + phone!.number));
                            if (user!) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  content: Text(
                                      'Cell number already exist try with different cell number'
                                          .tr())));
                            } else {
                              _submitPhoneNumber(phone!.countryCode + phone!.number);
                              startTimer();
                              setState(() {
                                _currentWidget=_otpVerication();
                              });
                            }
                          } else
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text('Enter cell number '.tr())));
                        } else
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Enter cell number '.tr())));
                      },
                      textColor: Colors.green,
                      child: Row(
                        children: [
                          Text(
                                  "Submit",
                                  style: TextStyle(fontSize: 20,color:Color(0xFF0573ac) ),
                                ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 30,
                            color: Color(0xFF0573ac),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.all(10),
                      shape: CircleBorder(),
                    ),
               ],
             ),
          ],)
    );
  }
  var resendFlag=false;
  var timerFlag=true;
  late Timer _timer;
  int _start = 60;
  String seconds="seconds";

  bool   _codeSent = false;


  void startTimer() {
    try {
      const oneSec = const Duration(seconds: 1);
      _timer = new Timer.periodic(
        oneSec,
            (Timer timer) {
          if (_start == 0) {
            setState(() {
              timer.cancel();
              seconds="second";
              resendFlag = true;
              timerFlag = false;
            });
          } else {
            setState(() {
              _start--;
            });
          }
        },
      );
    }catch(e){
      print(e);
    }
  }

  final numberController = TextEditingController();
  _otpVerication(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_cellNumber();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Enter OTP'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x494949),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 30,),

            Padding(
              padding:
              const EdgeInsets.only(top: 32.0, right: 24.0, left: 24.0),
              child:Container(

                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    shape: BoxShape.rectangle,
                    border: Border.all(color: Colors.grey.shade200)),
                child:  TextFormField(
                  textAlignVertical: TextAlignVertical.center,
                  textInputAction: TextInputAction.next,
                  style: TextStyle(fontSize: 18.0),
                  controller: numberController,
                  onChanged: (c) {
                    print(numberController.text.length.toString());
                    if (numberController.text.length == 6) {
                      FocusScope.of(context)
                          .requestFocus(FocusNode());
                    }
                  },
               //   onSaved: (val) => _phoneNumber = val,
                  keyboardType: TextInputType.phone,
                  cursorColor: Colors.grey.shade500,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.only(left: 16, right: 16),
                    hintText: '------'.tr(),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(
                            color: Colors.grey.shade500, width: 2.0)),
                    errorBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Theme.of(context).errorColor),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Theme.of(context).errorColor),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ),
            ),
             Row(
               mainAxisAlignment: MainAxisAlignment.end,
               children: [
                 MaterialButton(
                      onPressed: () async {
                        if(numberController.text.length<6){
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('Enter Code.'.tr()),
                            duration: Duration(seconds: 6),
                          ));
                        }else{
                          //push(context, OnBoardingQuestionOneScreen());
                          _submitOTP(numberController.text);
                        }
                      },
                      textColor: Colors.green,
                      child: Row(
                        children: [
                          Text(
                            "Verify",
                            style: TextStyle(fontSize: 20,color:Color(0xFF0573ac) ),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 30,
                            color: Color(0xFF0573ac),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.all(10),
                      shape: CircleBorder(),
                    ),
               ],
             ),

          ],)
    );
  }

  void _submitOTP(String smsCodes) {
    /// get the `smsCode` from the user


    /// when used different phoneNumber other than the current (running) device
    /// we need to use OTP to get `phoneAuthCredential` which is inturn used to signIn/login
    AuthCredential credential = PhoneAuthProvider.credential(verificationId: verificationId!, smsCode: smsCodes);

    _login(credential);
  }

  Future<void> _login(AuthCredential credential) async {
    /// This method is used to login the user
    /// `AuthCredential`(`_phoneAuthCredential`) is needed for the signIn method
    /// After the signIn method from `AuthResult` we can get `FirebaserUser`(`_firebaseUser`)
    try {
      await FirebaseAuth.instance
          .signInWithCredential(credential)
          .then(( authRes) async {
       // push(context, OnBoardingQuestionOneScreen());
        showProgress(context, 'Saving changes...'.tr(), true);
        user.phoneNumber =phone!.countryCode + phone!.number;
        us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
        hideProgress();
        if (updateUser != null) {
          this.user = updateUser;
          MyAppState.currentUser = user;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              duration: Duration(seconds: 3),
              content: Text(
                'Cell Number Updated Successfully.'.tr(),
                style: TextStyle(fontSize: 17),
              ),
            ),
          );
          setState(() {
            _currentWidget=_profileHome();
          });
        }
      }).catchError((e) {
        print(e);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Invalid OTP"),
          duration: Duration(seconds: 6),
        ));
      } );

    } catch (e) {
      print(e);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Invalid OTP"),
        duration: Duration(seconds: 6),
      ));
    }
  }

  _submitPhoneNumber(String phoneNumber) async {
    //send code
    await showProgress(context, 'Sending code...'.tr(), true);
    await FireStoreUtils.firebaseSubmitPhoneNumber(
      phoneNumber,
          (String verificationId) {
        if (mounted) {
          hideProgress();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Code verification timeout, request new code.'.tr(),
              ),
            ),
          );
          setState(() {
            _codeSent = false;
          });
        }
      },
          (String? verificationId, int? forceResendingToken) {
        if (mounted) {
          hideProgress();
          verificationId = verificationId;
          setState(() {
            _codeSent = true;
          });
        }
      },
          (FirebaseAuthException error) {
        if (mounted) {
          hideProgress();
          print('${error.message} ${error.stackTrace}');
          String message = 'An error has occurred, please try again.'.tr();
          switch (error.code) {
            case 'invalid-verification-code':
              message = 'Invalid code or has been expired.'.tr();
              break;
            case 'user-disabled':
              message = 'This user has been disabled.'.tr();
              break;
            default:
              message = 'An error has occurred, please try again.'.tr();
              break;
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                message,
              ),
            ),
          );
        }
      },
          (PhoneAuthCredential credential) async {
        if (mounted) {

        }
      },
    );
  }

  _Email(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Email Update'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x573ac),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 30,),

            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Email'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),
                      Text(
                        user.email,
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setState(() {
                        _currentWidget=_emailForm();
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Update',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            SizedBox(height: 30,),
            Text(
              "You can update your email any time. Click the Update link above, enter your new email address, and we'll send you a new code to verify your account.",
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xFF949494),
                  fontSize: 12),
              textAlign: TextAlign.start,
            ),
          ],)
    );
  }

  final emailController = TextEditingController();
  _emailForm(){
    return   Column(
      children: [
        SizedBox(height: 20,),
        MaterialButton(
          onPressed: () {
            setState(() {
              _currentWidget=_Email();
            });
          },
          textColor: Colors.green,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                Icons.arrow_back_ios,
                size: 30,
                color: Color(0xFF0573ac),
              ),
              InkWell(
                onTap: (){

                },
                child: Text(
                  'Enter Your Email Address'.tr(),
                  textScaleFactor: 1.0,
                  style: TextStyle(
                    color: Color(0xFF7b7b7b),
                    fontWeight: FontWeight.bold,
                    fontSize: 22,),
                  textAlign: TextAlign.center,
                ),
              ),
              Icon(
                Icons.arrow_back_ios,
                size: 30,
                color: Color(0x494949),
              ),
            ],
          ),
          padding: EdgeInsets.all(10),
          shape: CircleBorder(),
        ),

        SizedBox(height: 30,),
        Padding(
          padding: const EdgeInsets.only(
              top: 32.0, right: 24.0, left: 24.0),
          child: Container(
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                shape: BoxShape.rectangle,
                border: Border.all(color: Colors.grey.shade200)),
            child: TextFormField(
              controller: emailController,
              textAlignVertical: TextAlignVertical.center,
              textInputAction: TextInputAction.next,
              style: TextStyle(fontSize: 18.0),
              keyboardType: TextInputType.emailAddress,
              cursorColor: Color(COLOR_PRIMARY),
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                contentPadding:
                EdgeInsets.only(left: 16, right: 16),
                hintText: 'name@abc.com'.tr(),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: BorderSide(
                        color: Color(COLOR_PRIMARY), width: 2.0)),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: Theme.of(context).errorColor),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: Theme.of(context).errorColor),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide:
                  BorderSide(color: Colors.grey.shade200),
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            MaterialButton(
              onPressed: () async {
    String pattern =
    r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = RegExp(pattern);
    if (!regex.hasMatch(emailController.text)) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text('Enter valid email.'.tr()),
    duration: Duration(seconds: 6),
    ));
    } else {
      bool? user = await FireStoreUtils.getEmail(emailController.text);
      if (user!) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                'Email address already exist try with different email address.'
                    .tr())));
      } else {
        var rnd = Random();
        var next = rnd.nextDouble() * 1000000;
        while (next < 100000) {
          next *= 10;
        }
        emailOTP=(next.toInt());
        sendEmail("OTP :" + (next.toInt()).toString());
setState(() {
  _currentWidget=_emailOtpVerication();
});
        // push(context, OnBoardingQuestionEndScreen());
      }
    }
              },
              textColor: Colors.green,
              child: Row(
                children: [
                  Text(
                    "Send OTP",
                    style: TextStyle(fontSize: 20,color:Color(0xFF0573ac) ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),
          ],
        ),
      ],
    );
  }

  Future sendEmail( String message) async {

    String email= emailController.text;
    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');
    const serviceId = EMAILJSSERVICEID;
    const templateId = EMAILJSTEMPLATE;
    const userId = EMAILJSUSERID;
    final response = await http.post(url,
        headers: {
          'origin':'http://localhost',
          'Content-Type': 'application/json'},//This line makes sure it works for all platforms.
        body: json.encode({
          'service_id': serviceId,
          'template_id': templateId,
          'user_id': userId,
          'template_params': {
            'to_name': user.firstName,
            'to_email':email,
            'message': message
          }
        }));
    return response.statusCode;
  }

  final emailOTPController = TextEditingController();
  _emailOtpVerication(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_emailForm();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Enter Email OTP'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x494949),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 30,),

            Padding(
              padding:
              const EdgeInsets.only(top: 32.0, right: 24.0, left: 24.0),
              child:Container(

                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    shape: BoxShape.rectangle,
                    border: Border.all(color: Colors.grey.shade200)),
                child:  TextFormField(
                  textAlignVertical: TextAlignVertical.center,
                  textInputAction: TextInputAction.next,
                  style: TextStyle(fontSize: 18.0),
                  controller: numberController,
                  onChanged: (c) {
                    print(numberController.text.length.toString());
                    if (numberController.text.length == 6) {
                      FocusScope.of(context)
                          .requestFocus(FocusNode());
                    }
                  },
                  //   onSaved: (val) => _phoneNumber = val,
                  keyboardType: TextInputType.phone,
                  cursorColor: Colors.grey.shade500,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.only(left: 16, right: 16),
                    hintText: '------'.tr(),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(
                            color: Colors.grey.shade500, width: 2.0)),
                    errorBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Theme.of(context).errorColor),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide:
                      BorderSide(color: Theme.of(context).errorColor),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                MaterialButton(
                  onPressed: () async {
                    if(emailOTP.toString()==numberController.text.toString()){
                       showProgress(context, 'Saving changes...'.tr(), true);
                       user.email =emailController.text ;
                       us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                       hideProgress();
                       if (updateUser != null) {
                         this.user = updateUser;
                         MyAppState.currentUser = user;
                         ScaffoldMessenger.of(context).showSnackBar(
                           SnackBar(
                             duration: Duration(seconds: 3),
                             content: Text(
                               'Email Updated Successfully.'.tr(),
                               style: TextStyle(fontSize: 17),
                             ),
                           ),
                         );
                         setState(() {
                           _currentWidget=_profileHome();
                         });
                       }

                    }else{
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Enter valid OTP.'.tr()),
                        duration: Duration(seconds: 6),
                      ));
                    }
                  },
                  textColor: Colors.green,
                  child: Row(
                    children: [
                      Text(
                        "Verify",
                        style: TextStyle(fontSize: 20,color:Color(0xFF0573ac) ),
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 30,
                        color: Color(0xFF0573ac),
                      ),
                    ],
                  ),
                  padding: EdgeInsets.all(10),
                  shape: CircleBorder(),
                ),
              ],
            ),

          ],)
    );
  }



  _pushNotification(){
    return StatefulBuilder(builder: (context, StateSetter setStat) {

    return Padding(
      key: _myKey,
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Push Notification'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x573ac),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 10,),
            Text(
              "Push Notifications MUST be turned on to effectively use TruuBlue.",
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Colors.red,
                  fontSize: 12),
              textAlign: TextAlign.start,
            ),
            Text(
              "Setting Push Notification Services Off will severely limit results.",
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xFF949494),
                  fontSize: 12),
              textAlign: TextAlign.start,
            ),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'New Likes'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),notificationNewLkeFlag?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: SwitchListTile.adaptive(
        activeColor: Color(COLOR_ACCENT),
        value: newLike,
        onChanged: (bool newValue) {
          newLike = newValue;
          setStat(() {});
        }),
                          ),InkWell(
                            onTap: () async {
                              showProgress(context, 'Saving changes...'.tr(), true);
                              user.settings.pushSuperLikesEnabled = newLike;
                              us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                              hideProgress();
                              if (updateUser != null) {
                                this.user = updateUser;
                                MyAppState.currentUser = user;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    duration: Duration(seconds: 3),
                                    content: Text(
                                      'Settings saved successfully'.tr(),
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                );
                                setStat(() {
                                  notificationNewLkeFlag = false;
                                });
                              }
                            },
                            child: Text(
                              'Save',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  color: Color(0xFF949494),
                                  decoration: TextDecoration.underline,
                                  fontSize: 14),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ):
                      Text(
                        user.settings.pushSuperLikesEnabled?"ON":"OFF",
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setStat(() {
                        if(notificationNewLkeFlag){
                          notificationNewLkeFlag=false;
                        }else{
                          notificationNewLkeFlag=true;
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Toggle ON/OFF',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'New Matches'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),notificationNewMatchFlag?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: SwitchListTile.adaptive(
                                activeColor: Color(COLOR_ACCENT),
                                value: newMatch,
                                onChanged: (bool newValue) {
                                  newMatch = newValue;
                                  setStat(() {});
                                }),
                          ),InkWell(
                            onTap: () async {
                              showProgress(context, 'Saving changes...'.tr(), true);
                              user.settings.pushNewMatchesEnabled = newMatch;
                              us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                              hideProgress();
                              if (updateUser != null) {
                                this.user = updateUser;
                                MyAppState.currentUser = user;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    duration: Duration(seconds: 3),
                                    content: Text(
                                      'Settings saved successfully'.tr(),
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                );
                                setStat(() {
                                  notificationNewMatchFlag = false;
                                });
                              }
                            },
                            child: Text(
                              'Save',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  color: Color(0xFF949494),
                                  decoration: TextDecoration.underline,
                                  fontSize: 14),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ):
                      Text(
                        user.settings.pushNewMatchesEnabled?"ON":"OFF",
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setStat(() {
                        if(notificationNewMatchFlag){
                          notificationNewMatchFlag=false;
                        }else{
                          notificationNewMatchFlag=true;
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Toggle ON/OFF',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'New Messages'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),
                      notificationNewMessageFlag?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: SwitchListTile.adaptive(
                                activeColor: Color(COLOR_ACCENT),
                                value: newMessage,
                                onChanged: (bool newValue) {
                                  newMessage = newValue;
                                  setStat(() {});
                                }),
                          ),InkWell(
                            onTap: () async {
                              showProgress(context, 'Saving changes...'.tr(), true);
                              user.settings.pushNewMessages = newMessage;
                              us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                              hideProgress();
                              if (updateUser != null) {
                                this.user = updateUser;
                                MyAppState.currentUser = user;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    duration: Duration(seconds: 3),
                                    content: Text(
                                      'Settings saved successfully'.tr(),
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                );
                                setStat(() {
                                  notificationNewMessageFlag = false;
                                });
                              }
                            },
                            child: Text(
                              'Save',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  color: Color(0xFF949494),
                                  decoration: TextDecoration.underline,
                                  fontSize: 14),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ):
                      Text(
                        user.settings.pushNewMessages?"ON":"OFF",
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setStat(() {
                        if(notificationNewMessageFlag){
                          notificationNewMessageFlag=false;
                        }else{
                          notificationNewMessageFlag=true;
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Toggle ON/OFF',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'New Features & Updates'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),notificationNewFeaturesFlag?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: SwitchListTile.adaptive(
                                activeColor: Color(COLOR_ACCENT),
                                value: newFeatures,
                                onChanged: (bool newValue) {
                                  newFeatures = newValue;
                                  setStat(() {});
                                }),
                          ),InkWell(
                            onTap: () async {
                              showProgress(context, 'Saving changes...'.tr(), true);
                              user.settings.pushFeaturesUpdatesEnabled = newFeatures;
                              us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                              hideProgress();
                              if (updateUser != null) {
                                this.user = updateUser;
                                MyAppState.currentUser = user;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    duration: Duration(seconds: 3),
                                    content: Text(
                                      'Settings saved successfully'.tr(),
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                );
                                setStat(() {
                                  notificationNewFeaturesFlag = false;
                                });
                              }
                            },
                            child: Text(
                              'Save',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  color: Color(0xFF949494),
                                  decoration: TextDecoration.underline,
                                  fontSize: 14),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ):
                      Text(
                        user.settings.pushFeaturesUpdatesEnabled?"ON":"OFF",
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setStat(() {
                        if(notificationNewFeaturesFlag){
                          notificationNewFeaturesFlag=false;
                        }else{
                          notificationNewFeaturesFlag=true;
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Toggle ON/OFF',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Exclusive offers & News'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),

                            fontSize: 14),
                        textAlign: TextAlign.start,
                      ),notificationOffersNewsFlag?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 200,
                            child: SwitchListTile.adaptive(
                                activeColor: Color(COLOR_ACCENT),
                                value: newOffersNews,
                                onChanged: (bool newValue) {
                                  newOffersNews = newValue;
                                  setStat(() {});
                                }),
                          ),InkWell(
                            onTap: () async {
                              showProgress(context, 'Saving changes...'.tr(), true);
                              user.settings.pushOffersNewsEnabled = newOffersNews;
                              us.User? updateUser = await FireStoreUtils.updateCurrentUser(user);
                              hideProgress();
                              if (updateUser != null) {
                                this.user = updateUser;
                                MyAppState.currentUser = user;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    duration: Duration(seconds: 3),
                                    content: Text(
                                      'Settings saved successfully'.tr(),
                                      style: TextStyle(fontSize: 17),
                                    ),
                                  ),
                                );
                                setStat(() {
                                  notificationOffersNewsFlag = false;
                                });
                              }
                            },
                            child: Text(
                              'Save',
                              textScaleFactor: 1.0,
                              style: TextStyle(
                                  color: Color(0xFF949494),
                                  decoration: TextDecoration.underline,
                                  fontSize: 14),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ],
                      ):
                      Text(
                        user.settings.pushOffersNewsEnabled?"ON":"OFF",
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF949494),
                            fontSize: 12),
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                  InkWell(
                    onTap: (){
                      setStat(() {
                        if(notificationOffersNewsFlag){
                          notificationOffersNewsFlag=false;
                        }else{
                          notificationOffersNewsFlag=true;
                        }
                      });
                    },
                    child: Row(
                      children: [
                        Text(
                          'Toggle ON/OFF',
                          textScaleFactor: 1.0,
                          style: TextStyle(
                              color: Color(0xFF949494),
                              fontSize: 14),
                          textAlign: TextAlign.start,
                        ), SizedBox(width: 10,),Icon(
                          Icons.arrow_forward_ios,
                          size: 15,
                          color: Color(0xFF949494),
                        ),
                      ],
                    ),
                  )
                ],),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
          ],)
    );});
  }

  _pauseAccount(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: (){

                    },
                    child: Text(
                      'Pause Account'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x573ac),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 8.0,right: 8.0),
              child: Text(
                "Hide your profile from all TruuBlue users for a selected period. You will not lose any Likes, Matches, or Messages when you pause your account. Subscriptions do not pause.",
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),
                    fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 8.0,right: 8.0),
              child: Text(
                "How long would you like to pause your account?",
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),
                    fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 30,),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                '24 Hours'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                '48 Hours'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                '1 week'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.start,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                '1 month'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.start,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                'indefinitely'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.start,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
          ],)
    );
  }

  _deleteAccount(){
    return Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            MaterialButton(
              onPressed: () {
                setState(() {
                  _currentWidget=_AccountInformaton();
                });
              },
              textColor: Colors.green,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0xFF0573ac),
                  ),
                  InkWell(
                    onTap: () async {
                      AuthProviders? authProvider;
                      List<auth.UserInfo> userInfoList =
                          auth.FirebaseAuth.instance.currentUser?.providerData ??
                              [];
                      await Future.forEach(userInfoList, (auth.UserInfo info) {
                        switch (info.providerId) {
                          case 'password':
                            authProvider = AuthProviders.PASSWORD;
                            break;
                          case 'phone':
                            authProvider = AuthProviders.PHONE;
                            break;
                          case 'facebook.com':
                            authProvider = AuthProviders.FACEBOOK;
                            break;
                          case 'apple.com':
                            authProvider = AuthProviders.APPLE;
                            break;
                        }
                      });
                      bool? result = await showDialog(
                        context: context,
                        builder: (context) => ReAuthUserScreen(
                          provider: authProvider!,
                          email: auth.FirebaseAuth.instance.currentUser!.email,
                          phoneNumber:
                          auth.FirebaseAuth.instance.currentUser!.phoneNumber,
                          deleteUser: true,
                        ),
                      );
                      if (result != null && result) {
                        await showProgress(
                            context, 'Deleting account...'.tr(), false);
                      await FireStoreUtils.deleteUser();
                      await hideProgress();
                      MyAppState.currentUser = null;
                      pushAndRemoveUntil(context, AuthScreen(), false);
                    }
                    },
                    child: Text(
                      'Delete Account'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF7b7b7b),
                        fontWeight: FontWeight.bold,
                        fontSize: 22,),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Icon(
                    Icons.arrow_back_ios,
                    size: 30,
                    color: Color(0x573ac),
                  ),
                ],
              ),
              padding: EdgeInsets.all(10),
              shape: CircleBorder(),
            ),

            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 8.0,right: 8.0),
              child: Text(
                "If you delete your account, all Like, Matches, and Messages, and all Settings will be deleted. Alternatively, we strongly suggest Pausing your account.",
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),
                    fontSize: 12),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 30,),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                'Pause my account instead'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,bottom: 10.0),
              child:Text(
                'Delete My Account'.tr(),
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF949494),

                    fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ),
            Divider(color:Color(0xFF7e7e7e) ,height: 0.3,),
          ],)
    );
  }


}
