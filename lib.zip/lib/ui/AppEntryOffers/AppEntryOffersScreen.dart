import 'package:dating/help/responsive_ui.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';

class AppEntryOffersScreen extends StatefulWidget {
  const AppEntryOffersScreen({Key? key}) : super(key: key);

  @override
  _AppEntryOffersState createState() => _AppEntryOffersState();
}

class _AppEntryOffersState extends State<AppEntryOffersScreen> {
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  GlobalKey<FormState> _key = GlobalKey();

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            children: [
              Container(
                  width: MediaQuery.of(context).size.width - 40,
                  decoration: BoxDecoration(
                      color: Color(0xFFf3fbff),
                      border: Border.all(
                        color: Colors.grey,
                        width: 1,
                      )),
                  child: Column(children: [
                    Padding(
                        padding: const EdgeInsets.only(
                            left: 16, top: 12, right: 16, bottom: 8),
                        child: Text(
                          "Who's Interested In You".tr(),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFF5d5c5c),
                            fontWeight: FontWeight.bold,
                            fontSize: _large! ? 25 : (_medium! ? 22 : 20),
                          ),
                        )),
                    SizedBox(
                      height: 20,
                    ),
                    Center(
                      child: Text(
                        "14 Likes".tr(),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.underline,
                            color: Color(0xFF0573ac),
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    )
                  ])),
              SizedBox(
                height: 30,
              ),
              Container(
                  width: MediaQuery.of(context).size.width - 40,
                  decoration: BoxDecoration(
                      color: Color(0xFFf3fbff),
                      border: Border.all(
                        color: Colors.grey,
                        width: 1,
                      )),
                  child: Column(children: [
                    Padding(
                        padding: const EdgeInsets.only(
                            left: 16, top: 12, right: 16, bottom: 0),
                        child: Text(
                          "Get Noticed".tr(),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFF5d5c5c),
                            fontWeight: FontWeight.bold,
                            fontSize: _large! ? 30 : (_medium! ? 25 : 20),
                          ),
                        )),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child:  Padding(
                        padding: const EdgeInsets.only(top: 5,right: 20.0,left: 20),
                        child: Text(
                          "Move to the front of the search queue. Boost your profile and rank higher in search results for the next 30 minutes.".tr(),
                          style:
                          TextStyle(color: Color(0xFF707070), fontSize: 12.0),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 40.0, left: 40.0, top: 0),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(minWidth: double.minPositive),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Color(0xFF70573ac),
                            textStyle: TextStyle(color: Colors.white),
                            padding: EdgeInsets.only(right:50,left: 50,top: 5, bottom: 5),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                side: BorderSide(color: Color(0xFF0573ac))),
                          ),
                          child: Text(
                            'BOOST!'.tr(),
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          onPressed: () {


                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    )
                  ])),
              SizedBox(
                height: 30,
              ),
              Container(
                  width: MediaQuery.of(context).size.width - 40,
                  decoration: BoxDecoration(
                      color: Color(0xFFf3fbff),
                      border: Border.all(
                        color: Colors.grey,
                        width: 1,
                      )),
                  child: Column(children: [
                    Padding(
                        padding: const EdgeInsets.only(
                            left: 16, top: 12, right: 16, bottom: 0),
                        child: Text(
                          "Upgrade - Premium Plan".tr(),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFF5d5c5c),
                            fontWeight: FontWeight.bold,
                            fontSize: _large! ? 25 : (_medium! ? 22 : 20),
                          ),
                        )),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child:  Padding(
                        padding: const EdgeInsets.only(top: 5,right: 20.0,left: 20),
                        child: Text(
                          "Unlock all of our features to be in complete control of your online dating experience.".tr(),
                          style:
                          TextStyle(color: Color(0xFF707070), fontSize: 12.0),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 40.0, left: 40.0, top: 0),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(minWidth: double.minPositive),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Color(0xFF70573ac),
                            textStyle: TextStyle(color: Colors.white),
                            padding: EdgeInsets.only(right:40,left: 40,top: 5, bottom: 5),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0),
                                side: BorderSide(color: Color(0xFF0573ac))),
                          ),
                          child: Text(
                            'UPGRADE!'.tr(),
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          onPressed: () {


                          },
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    )
                  ])),
            ],
          ),
        ),
      ),
    );
  }
}
