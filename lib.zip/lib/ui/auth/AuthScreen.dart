import 'package:dating/constants.dart' as Constants;
import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingSignUpInfo.dart';
import 'package:dating/ui/phoneAuth/PhoneNumberInputScreen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({Key? key}) : super(key: key);

  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;

  Position? signUpLocation;

  @override
  void initState() {
    super.initState();
    getlocation().then((value) {
      if (value != null || signUpLocation != null) {
        getNotification();
      }
    });
    getNotification();
  }
  Future<Position?> getlocation() async {
    Future.delayed(const Duration(milliseconds: 500), () async {
      signUpLocation = await getCurrentLocation();

      setState(() {
        if (signUpLocation != null) {
          getNotification();
        }
      });
    });
    return signUpLocation;
  }

  getNotification() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');

    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');

    } else {
      print('User declined or has not accepted permission');
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(Constants.COLOR_PRIMARY),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding:
              const EdgeInsets.only(left: 40.0, top: 32, right: 40.0, bottom: 0),
              child: Text(
                'Welcome to TruuBlue'.tr(),
                textAlign: TextAlign.start,
                textScaleFactor: 1.0,
                style: TextStyle(
                    color: Color(0xFF0573ac),
                    fontSize: _large! ? 32 : (_medium! ? 30 : 23),
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 40.0, left: 40.0,top: 10, bottom: 0),
            child: Text(
              'Register today to meet amazing people near you'.tr(),
              textScaleFactor: 1.0,
              style: TextStyle(fontSize: 22 ,color: Color(0xFF707070),),
              textAlign: TextAlign.start,
            ),
          ),
          SizedBox(
            height: 100,
          ),
          Center(
            child: Image.asset(
              'assets/images/truubluenew.png',
              width: 300.0,
              height: 120.0,
            ),
          ),
          SizedBox(
            height: 100,
          ),
          Padding(
            padding: const EdgeInsets.only(right: 70.0, left: 70.0, top: 40),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minWidth: double.infinity),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Color(COLOR_BLUE_BUTTON),
                  textStyle: TextStyle(color: Colors.white),
                  padding: EdgeInsets.only(top: 12, bottom: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25.0),
                      side: BorderSide(color: Color(COLOR_BLUE_BUTTON))),
                ),
                child: Text(
                  'Log In'.tr(),
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                onPressed: () {
                  //push(context, LoginScreen());
                  push(context, PhoneNumberInputScreen(login: true));
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(
                right: 70.0, left: 70.0, top: 20, bottom: 20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minWidth: double.infinity),
              child: TextButton(
                style: ButtonStyle(
                  backgroundColor:MaterialStateProperty.all<Color>( Colors.white),
                  padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
                    EdgeInsets.only(top: 12, bottom: 12),
                  ),
                  shape: MaterialStateProperty.all<OutlinedBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25.0),
                      side: BorderSide(
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                child: Text(
                  'Sign Up'.tr(),
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(COLOR_BLUE_BUTTON)),
                ),
                onPressed: () {
                  //push(context, SignUpScreen());
                  push(context, OnBoardingSignUpInfo());
                },
              ),
            ),
          )
        ],
      ),
    );
  }

}
