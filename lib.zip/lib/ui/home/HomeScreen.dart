import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dating/constants.dart';
import 'package:dating/main.dart';
import 'package:dating/model/User.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/auth/AuthScreen.dart';
import 'package:dating/ui/homeBottom/HomeBottomNavScreen.dart';
import 'package:dating/ui/profile/MainProfileScreen.dart';
import 'package:dating/ui/profile/ProfileScreen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:shared_preferences/shared_preferences.dart';


enum DrawerSelection { Conversations, Contacts, Search, Profile }

class HomeScreen extends StatefulWidget {
  final User user;

  HomeScreen({Key? key, required this.user}) : super(key: key);

  @override
  _HomeState createState() {
    return _HomeState();
  }
}

class _HomeState extends State<HomeScreen> {
  late User user;
  String _appBarTitle = 'Swipe'.tr();
  late Widget _currentWidget;

  @override
  void initState() {
    super.initState();
    if (MyAppState.currentUser!.isVip) {
      checkSubscription();
    }
    user = widget.user;
    _updateGenderPreference();
    _currentWidget = HomeBottomNavScreen(
        user: user); //AppEntryOffersScreen();//SwipeScreen();
    FireStoreUtils.firebaseMessaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
  }
  _updateGenderPreference() async {
    user.settings.genderPreference = "All";
    User? updateUser = await FireStoreUtils.updateCurrentUser(user);
    //hideProgress();
    if (updateUser != null) {
      this.user = updateUser;
      MyAppState.currentUser = user;
    }
  }


  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: user,
      child: Consumer<User>(
        builder: (context, user, _) {
          return Scaffold(
            appBar: AppBar(
              title: GestureDetector(
                onTap: () {
                  setState(() {
                    _appBarTitle = 'Swipe'.tr();
                    _currentWidget = HomeBottomNavScreen(
                        user: user); //AppEntryOffersScreen();//SwipeScreen();
                  });
                },
                child: Image.asset(
                  'assets/images/truubluenew.png',
                  width: _appBarTitle == 'Swipe'.tr() ? 150 : 150,
                  height: _appBarTitle == 'Swipe'.tr() ? 150 : 150,
                  /*color: _appBarTitle == 'Swipe'.tr()
                      ? Color(COLOR_PRIMARY)
                      : Colors.grey,*/
                ),
              ),
              leading: Padding(
                padding: const EdgeInsets.all(12.0),
                child: GestureDetector(
                    child: user.profilePictureURL != ''
                        ? Container(
                            width: _appBarTitle == 'Profile'.tr() ? 35 : 24,
                            height: _appBarTitle == 'Profile'.tr() ? 35 : 24,
                            decoration: new BoxDecoration(
                                color: const Color(0xff7c94b6),
                                borderRadius: BorderRadius.all(Radius.circular(30)),
                                border: Border.all(
                                  color: Colors.blue,
                                  width: 0.5 ,
                                ),
                                image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: NetworkImage(user.profilePictureURL))))
                        : Container(
                            width: _appBarTitle == 'Profile'.tr() ? 35 : 24,
                            height: _appBarTitle == 'Profile'.tr() ? 35 : 24,
                            decoration: new BoxDecoration(
                                color: const Color(0xff7c94b6),
                                borderRadius: BorderRadius.all(Radius.circular(30)),
                                border: Border.all(
                                  color: Colors.blue,
                                  width: 0.5 ,
                                ),
                                image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: AssetImage(
                                      'assets/images/placeholder.jpg',
                                    )))),
                    /*displayCircleImage(
                          user.profilePictureURL,_appBarTitle == 'Profile'.tr() ? 50 : 40,  false),*/
                    onTap: () {
                      setState(() {
                        _appBarTitle = 'Profile'.tr();
                        _currentWidget = MainProfileScreen(user:user);//ProfileScreen(user: user);
                      });
                    }),
              ),
              actions: <Widget>[
                PopupMenuButton(
                  icon: Icon(Icons.view_headline_rounded,color: Color(COLOR_BLUE_BUTTON),size: _appBarTitle == 'Conversations'.tr() ? 35 : 24,),
                  offset: Offset(0, 55),
                  onSelected: _select,
                  itemBuilder: (BuildContext context) {
                    return {/*'Account', 'Dating Tips', 'Legal', 'Close Account',*/'Logout'}.map((String choice) {
                      return PopupMenuItem(
                        value: choice,
                        child: Text(choice),
                      );
                    }).toList();
                  },
                )
              ],/*<Widget>[
                IconButton(
                  icon: Icon(Icons.view_headline_rounded),
                  onPressed: () {
                    setState(() {
                      _appBarTitle = 'Conversations'.tr();
                      _currentWidget = ConversationsScreen(user: user);
                    });
                  },
                  color: _appBarTitle == 'Conversations'.tr()
                      ? Color(COLOR_BLUE_BUTTON)
                      : Colors.grey,
                  iconSize: _appBarTitle == 'Conversations'.tr() ? 35 : 24,
                )
              ],*/
              backgroundColor: Colors.transparent,
              brightness:
                  isDarkMode(context) ? Brightness.dark : Brightness.light,
              centerTitle: true,
              elevation: 0,
            ),
            body: SafeArea(child: _currentWidget),
          );
        },
      ),
    );
  }

  void checkSubscription() async {
    await showProgress(context, 'Loading...', false);
    await FireStoreUtils.isSubscriptionActive();
    await hideProgress();
  }

  Future<void> _select(value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    switch (value) {
      case 'Account':

        break;
      case 'Dating Tips':

        break;
      case 'Legal':

        break;
    case 'Close Account':

    break;
    case 'Logout':
      user.active = false;
      user.lastOnlineTimestamp = Timestamp.now();
      await FireStoreUtils.updateCurrentUser(user);
      await auth.FirebaseAuth.instance.signOut();
      MyAppState.currentUser = null;
      prefs.setString("loginMobile", "");
      pushAndRemoveUntil(context, AuthScreen(), false);
    break;
    }
    //print(value);
  }
}
