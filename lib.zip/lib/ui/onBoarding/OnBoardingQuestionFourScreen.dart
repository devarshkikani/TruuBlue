import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionFiveScreen.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:flutter_holo_date_picker/flutter_holo_date_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

import 'OnBoardingOtpVerficationScreen.dart';

class OnBoardingQuestionFourScreen extends StatefulWidget {
  const OnBoardingQuestionFourScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionFourScreenState createState() => _OnBoardingQuestionFourScreenState();
}

class _OnBoardingQuestionFourScreenState extends State<OnBoardingQuestionFourScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String?  _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  SfRangeValues _OneSliderValue =SfRangeValues(30,50);
 var numberController = TextEditingController();

  @override
  void initState() {
    super.initState();
    print(numberController.text);
    if(numberController.text.length==2){
      numberController.text=numberController.text+"/";
    }else if(numberController.text.length==5){
    numberController.text=numberController.text+"/";
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    RangeValues _currentRangeValues = const RangeValues(30, 40);

    String _selectedDate = '';

    Future<void> _selectDate(BuildContext context) async {
      /*final DateTime? d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1950),
        lastDate: DateTime(2023),

      );*/

      var datePicked = await DatePicker.showSimpleDatePicker(
        context,
        initialDate: DateTime(1994),
        firstDate: DateTime(1960),
        lastDate: DateTime(2012),
        dateFormat: "dd-MMM-yyyy",
        locale: DateTimePickerLocale.en_us,
        looping: true,
      );
      if (datePicked != null)
        setState(() {
          numberController.text = new DateFormat('MM/dd/yyyy').format(datePicked);
        });
    }
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 30,
                ),

                Align(
                    alignment: Directionality.of(context) == TextDirection.LTR
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(

                      'What is your birthdate?'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color:  Color(0xFF0573ac),
                        fontWeight: FontWeight.bold,
                        fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 10, right: 0, bottom: 8),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [SizedBox(
                        height: 20,
                      ),
                      Padding(
                        padding:
                        const EdgeInsets.only(top: 32.0, right: 24.0, left: 24.0),
                        child:Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              shape: BoxShape.rectangle,
                              border: Border.all(color: Colors.grey.shade200)),
                          child:  InkWell(
                            onTap: (){
                              _selectDate(context);
                            },
                            child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              textInputAction: TextInputAction.next,
                              style: TextStyle(fontSize: 18.0),
                              enabled: false,
                              controller: numberController,
                              onSaved: (val){
                                print(val);
                                _phoneNumber = val;
                                if(_phoneNumber?.length==2){
                                  _phoneNumber=(_phoneNumber!+"/");
                                }else if(_phoneNumber!.length==5){
                                  _phoneNumber=_phoneNumber!+"/";
                                }
                                },
                              keyboardType: TextInputType.text,
                              cursorColor: Colors.grey.shade500,
                              textAlign: TextAlign.center,
                              decoration: InputDecoration(
                                contentPadding: EdgeInsets.only(left: 16, right: 16,bottom: 12),
                                hintText: 'MM/DD/YYYY'.tr(),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: BorderSide(
                                        color: Colors.grey.shade500, width: 2.0)),
                                errorBorder: OutlineInputBorder(
                                  borderSide:
                                  BorderSide(color: Theme.of(context).errorColor),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                focusedErrorBorder: OutlineInputBorder(
                                  borderSide:
                                  BorderSide(color: Theme.of(context).errorColor),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.grey.shade200),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding:
                  const EdgeInsets.only(left: 0, top: 20, right: 16, bottom: 8),
                  child: Text(
                    "What is your age preference?".tr(),
                    textScaleFactor: 1.0,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: Color(0xFF707070),
                        fontWeight: FontWeight.bold,
                        fontSize: _large! ? 30 : (_medium! ? 25 : 20),
                  ),
                ),),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 0, right: 10, bottom: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "18".tr(),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "99".tr(),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                    ],
                  ),
                ),
                SfRangeSlider(
                  min: 18.0,
                  max: 99.0,
                  values: _OneSliderValue,
                  interval: 20,
                  showTicks: false,
                  showLabels: false,
                  activeColor: Color(0xFF68cf00),
                  inactiveColor: Colors.grey,
                  enableTooltip: true,
                  tooltipTextFormatterCallback:
                      (dynamic actualValue, String formattedText) {
                    return actualValue.toStringAsFixed(0);
                  },
                  minorTicksPerInterval: 1,
                  startThumbIcon:Stack(
                    children:[
                      Container(
                      decoration: new BoxDecoration(
                        color: Color(COLOR_BLUE_BUTTON),
                        shape: BoxShape.circle,
                      ),
                    ),
                      Center(child: Text(_OneSliderValue.start!.toStringAsFixed(0),style: TextStyle(color: Colors.white,fontSize: 10)))]
                  ) ,
                  endThumbIcon: Center(
                    child: Stack(
                      children: [
                        Container(

                          decoration: new BoxDecoration(
                            color: Color(COLOR_BLUE_BUTTON),
                            shape: BoxShape.circle,
                          ),
                        ),Center(child: Text(_OneSliderValue.end!.toStringAsFixed(0),style: TextStyle(color: Colors.white,fontSize: 10),))
                      ],
                    ),
                  ) ,
                  onChanged: (SfRangeValues values){
                    setState(() {
                      _OneSliderValue = values;
                    });
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar:Padding(
        padding: const EdgeInsets.fromLTRB(20,0,20,50),
        child:
            Text(
              "We only show your age to potential matches, never your birthdate. You can adjust the age range later.".tr(),
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xff525354),
                  fontWeight: FontWeight.normal,
                  fontSize: 15.0),
              textAlign: TextAlign.center,
            ),
      ),

      appBar:PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,50,20,0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                       /* Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      if(numberController.text.isEmpty){
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Please enter birthdate.'.tr(),
                            ),
                          ),
                        );
                      }else{
                        setSetQuestionPreferences("birthdate",numberController.text);
                        setSetQuestionPreferences("age_prefrance_start",_OneSliderValue.start!.toString());
                        setSetQuestionPreferences("age_prefrance_end",_OneSliderValue.end!.toString());
                        push(context, OnBoardingQuestionFiveScreen());
                      }
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> setSetQuestionPreferences(String key,String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
