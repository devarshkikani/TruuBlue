import 'package:dating/Cache.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionTwoScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../constants.dart';

class OnBoardingQuestionOneScreen extends StatefulWidget {
  const OnBoardingQuestionOneScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionOneScreenState createState() =>
      _OnBoardingQuestionOneScreenState();
}

class _OnBoardingQuestionOneScreenState
    extends State<OnBoardingQuestionOneScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  PageController pageController = PageController();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  int SelectedIndex=0;
  String selection='She/her/hers'.tr();
  final List<String> _PreferPronounList = [
    'She/her/hers'.tr(),
    'He/him/his'.tr(),
    'They/them/theirs'.tr(),
    'Ze/hir/hirs'.tr(),
    'Ze/zir/zirs'.tr(),
    'Prefer not to include'.tr(),
  ];

  final numberController = TextEditingController();

  String?  _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 20,
                ),
                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(
                      "What's your first name?" .tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(

                        color: Color(0xFF0573ac),
                        fontWeight: FontWeight.bold,
                        fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 10, right: 0, bottom: 8),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "This will be displayed on your profile.".tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF707070),
                            fontSize: 18.0),
                        textAlign: TextAlign.start,
                      ),SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding:
                        const EdgeInsets.only(top: 10.0, right: 24.0, left: 24.0),
                        child:Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              shape: BoxShape.rectangle,
                              border: Border.all(color: Colors.grey.shade200)),
                          child:  TextFormField(
                            textAlignVertical: TextAlignVertical.center,
                            textInputAction: TextInputAction.next,
                            style: TextStyle(fontSize: 18.0),
                            onSaved: (val) => _phoneNumber = val,
                            controller: numberController,
                            keyboardType: TextInputType.text,
                            cursorColor: Colors.grey.shade500,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 16, right: 16),
                              hintText: ''.tr(),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                      color: Colors.grey.shade500, width: 2.0)),
                              errorBorder: OutlineInputBorder(
                                borderSide:
                                BorderSide(color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide:
                                BorderSide(color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.grey.shade200),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(
                      "What are your preferred pronouns?" .tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(

                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize:  _large! ? 30 : (_medium! ? 25 : 20),),
                      textAlign: TextAlign.start,
                    )),
                SizedBox(
                  height: 10,
                ),
                Container(

                  child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      itemCount: _PreferPronounList.length,
                      itemBuilder: (BuildContext context, int index) {
                        return _PreferPronounItem(
                            _PreferPronounList[index],index);
                      }),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(20,0,20,50),
        child: Text(
          "This information is shared with other members.\nYou will not be able to change your name later.".tr(),
          textScaleFactor: 1.0,
          style: TextStyle(
              color: Color(0xff525354),
              fontWeight: FontWeight.normal,
              fontSize: 13.0),
          textAlign: TextAlign.center,
        ),
            /*Column(
              children: [

                Padding(
                  padding: const EdgeInsets.only(bottom: 30.0),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: SmoothPageIndicator(
                      controller: pageController,
                      count: 10,
                      effect: ScrollingDotsEffect(
                          activeDotColor: Colors.white,
                          dotColor: Colors.grey.shade400,
                          dotWidth: 8,
                          dotHeight: 8,
                          fixedCenter: true),
                    ),
                  ),
                )
              ],
            ),*/
      ), appBar:PreferredSize(
              preferredSize: const Size.fromHeight(100),
              child: Padding(
        padding: const EdgeInsets.fromLTRB(20,50,20,0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                       /* Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      if(numberController.text.isEmpty){
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Enter First Name.'.tr(),
                            ),
                          ),
                        );
                      }else{
                        setSetQuestionPreferences(
                            "first_name", numberController.text);
                        setSetQuestionPreferences(
                            "prefer_pronoun", selection);
                        push(context, OnBoardingQuestionTwoScreen());
                      }

                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
          ],
        ),
      ),
            ),
    );

  }

  _PreferPronounItem(String _list,int index) {
    return Container(
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.only(left: 5, top:0, right: 5, bottom: 0),
        child:Column(
        children: [
          InkWell(
            child: Padding(
              padding: const EdgeInsets.only(left: 5, top:5, right: 5, bottom: 5),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 20,
                      child: Transform.scale(
                        scale: 1.3,
                        child: Checkbox(value: SelectedIndex==index,
                            activeColor: Color(0xFF66BB6A),
                            onChanged:(bool? newValue){
                              setState(() {
                                SelectedIndex=index;
                                Cache().setPreferPronoun(_list);
                                selection=_list;
                              });
                            }),
                      ),
                    ),
                    /*Visibility(
                        visible:SelectedIndex==index,child: Icon(Icons.check,color: Colors.blue,)),*/
                    Padding(
                      padding: const EdgeInsets.only(top: 0,bottom: 0),
                      child: Text(
                        _list.tr(),
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,color: Colors.black),
                      ),
                    ),

                  ],
                ),
            ),
            onTap: (){
              setState(() {
               /* SelectedIndex=index;
                Cache().setPreferPronoun(_list);
                selection=_list;*/
              });
            },
          ),
          //Divider(color: Colors.grey,height: 1,)
        ],
      )),
    );
  }
  Future<bool> setSetQuestionPreferences(String key,String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
