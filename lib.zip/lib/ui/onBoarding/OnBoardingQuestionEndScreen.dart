import 'dart:io';

import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/main.dart';
import 'package:dating/model/User.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/home/HomeScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnBoardingQuestionEndScreen extends StatefulWidget {
  const OnBoardingQuestionEndScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionEndScreenState createState() => _OnBoardingQuestionEndScreenState();
}

class _OnBoardingQuestionEndScreenState extends State<OnBoardingQuestionEndScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String? _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  Position? signUpLocation;

  @override
  void initState() {
    super.initState();
    getlocation().then((value) {
      if (value != null || signUpLocation != null) {
        getNotification();
      }
    });
    getNotification();
  }
  Future<Position?> getlocation() async {
    Future.delayed(const Duration(milliseconds: 500), () async {
      signUpLocation = await getCurrentLocation();

      setState(() {
        if (signUpLocation != null) {
          getNotification();
        }
      });
    });
    return signUpLocation;
  }

  getNotification() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
      setState(() {

      });
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');
      setState(() {

      });
    } else {
      print('User declined or has not accepted permission');
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),
      body: SingleChildScrollView(
        child:   Padding(
          padding: const EdgeInsets.only(left: 40.0,right: 40,bottom: 16),
          child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 30,
                  ),
                  Align(
                      alignment: Directionality.of(context) == TextDirection.ltr
                          ? Alignment.topLeft
                          : Alignment.topLeft,
                      child: Text(
                        'Awesome!'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(

                          color: Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize: _large! ? 32 : (_medium! ? 30 : 25),
                        ),
                        textAlign: TextAlign.start,
                      )),

                  /// user profile picture,  this is visible until we verify the
                  /// code in case of sign up with phone number
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 0, top: 10, right: 0, bottom: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        RichText(
                          textScaleFactor: 1.0,
                          text: new TextSpan(
                            // Note: Styles for TextSpans must be explicitly defined.
                            // Child text spans will inherit styles from parent
                            style: new TextStyle(
                              fontSize: 13.0,
                              color:  Colors.black,
                            ),
                            children: <TextSpan>[
                              TextSpan(
                                  text:
                                  "Are you ready to start meeting link-minded progressives in your area?"
                                      .tr()),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Row(
                          children: [

                            Container(
                                width: 3,height: 250,
                                color: Colors.black,
                              ),

                            SizedBox(
                              width: 20,
                            ),
                            Container(
                              width: 260,
                              child:
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Remember:'.tr(),
                                        style: TextStyle(
                                          color: Color(0xFF4a4a4a),
                                          fontWeight: FontWeight.bold,
                                          fontSize: _large! ? 20 : (_medium! ? 18 : 16),
                                        ),
                                        textAlign: TextAlign.start,
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Text(
                                        "Your matches only last for 48 hours, so make sure Notifications are turned 'ON' for TruuBlue".tr(),
                                        textScaleFactor: 1.0, style: TextStyle(
                                            color:  Colors.black,
                                          fontSize: _large! ? 16 : (_medium! ? 15 : 12)),
                                        textAlign: TextAlign.start,
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "Check your inbox for an email from TruuBlue to verify your email address".tr(),
                                        textScaleFactor: 1.0,style: TextStyle(
                                            color:  Colors.black,
                                          fontSize: _large! ? 16 : (_medium! ? 15 : 12)),
                                        textAlign: TextAlign.start,
                                      ),SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "Don't give out personal data like your home address or cell number".tr(),
                                        textScaleFactor: 1.0,style: TextStyle(
                                            color:  Colors.black,
                                          fontSize: _large! ? 16 : (_medium! ? 15 : 12)),
                                        textAlign: TextAlign.start,
                                      ),SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "Report any bad actors to TruuBlue Immediately".tr(),
                                        textScaleFactor: 1.0,style: TextStyle(
                                            color:  Colors.black,
                                            fontSize: _large! ? 16 : (_medium! ? 15 : 12)),
                                        textAlign: TextAlign.start,
                                      ),
                                    ],
                                  )
                            ),
                          ],
                        )
                      ],
                    ),
                  ),

                  SizedBox(
                    height: 20,
                  ),
                ],

            ),
        ),
      ),
      bottomNavigationBar:Padding(
        padding: const EdgeInsets.fromLTRB(40, 0, 40, 50),
        child:
            Text(
              "Let's Go!".tr(),
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(COLOR_BLUE_BUTTON),
                  fontWeight: FontWeight.bold,
                  fontSize: 40.0),
              textAlign: TextAlign.center,
            ),
      ),
      appBar:PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      //push(context, OnBoardingQuestionEndScreen());
                      _signUpWithEmailAndPassword();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _signUpWithEmailAndPassword() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    await showProgress(
        context, 'Creating new account, Please wait...'.tr(), false);
    signUpLocation = await getCurrentLocation();
    if (signUpLocation != null) {
      dynamic result = await FireStoreUtils.firebaseSignUpWithEmailAndPassword(
        prefs.getString("email") ?? '',
        "123456",
        File(prefs.getString("imageOne")!),
        File(prefs.getString("imageTwo")!),
        File(prefs.getString("imageThree")!),
        File(prefs.getString("imageFour")!),
        File(prefs.getString("imageFive")!),
        File(prefs.getString("imageSix")!),
        prefs.getString("first_name") ?? '',
        "x",
        signUpLocation!,
        prefs.getString("cell_number") ?? '',
        prefs.getString("prefer_pronoun") ?? '',
        prefs.getString("Q1") ?? '',
        prefs.getString("Q2") ?? '',
        prefs.getString("Q3") ?? '',
        prefs.getString("Q4") ?? '',
        prefs.getString("Q5") ?? '',
        prefs.getString("Q6") ?? '',
        prefs.getString("Q1_Deal_Breaker") ?? '',
        prefs.getString("Q2_Deal_Breaker") ?? '',
        prefs.getString("Q3_Deal_Breaker") ?? '',
        prefs.getString("Q4_Deal_Breaker") ?? '',
        prefs.getString("Q5_Deal_Breaker") ?? '',
        prefs.getString("Q6_Deal_Breaker") ?? '',
        prefs.getString("birthdate") ?? '',
        prefs.getString("age_prefrance_start") ?? '',
        prefs.getString("age_prefrance_end") ?? '',
        prefs.getString("Your_Gender") ?? '',
        prefs.getString("Want_Date_Gender") ?? '',
        prefs.getString("Your_Sexuality") ?? '',
        prefs.getString("Want_Date_Sexuality") ?? '',
        prefs.getString("Your_Ethnicity") ?? '',
        prefs.getString("Want_Date_Ethnicity") ?? '',
        prefs.getString("You_Drink") ?? '',
        prefs.getString("Want_Date_Drink") ?? '',
        prefs.getString("You_Smoke") ?? '',
        prefs.getString("Want_Date_Smoke") ?? '',
        prefs.getString("You_Children") ?? '',
        prefs.getString("Want_Date_Children") ?? '',
      );
      await hideProgress();
      if (result != null && result is User) {
        MyAppState.currentUser = result;
        pushAndRemoveUntil(context, HomeScreen(user: result), false);
      } else if (result != null && result is String) {
        showAlertDialog(context, 'Failed'.tr(), result);
      } else {
        showAlertDialog(context, 'Failed'.tr(), 'Couldn\'t sign up'.tr());
      }
    } else {
      await hideProgress();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Location is required to match you with people from '
            'your area.'
            .tr()),
        duration: Duration(seconds: 6),
      ));
    }
  }
}
