import 'dart:convert';
import 'dart:math';

import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'OnBoardingQuestionEndScreen.dart';
import 'OnBoardingQuestionFifteenScreen.dart';

class OnBoardingQuestionFourteenScreen extends StatefulWidget {
  const OnBoardingQuestionFourteenScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionFourteenScreenState createState() =>
      _OnBoardingQuestionFourteenScreenState();
}

class _OnBoardingQuestionFourteenScreenState
    extends State<OnBoardingQuestionFourteenScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String? _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  final emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 30,
                ),
                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(
                      'Enter your email address'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                        color: Color(0xFF0573ac),
                        fontWeight: FontWeight.bold,
                        fontSize: _large! ? 32 : (_medium! ? 30 : 25),
                      ),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 10, right: 0, bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        textScaleFactor: 1.0,
                        text: new TextSpan(
                          // Note: Styles for TextSpans must be explicitly defined.
                          // Child text spans will inherit styles from parent
                          style: new TextStyle(
                            fontSize: 15.0,
                            color: Color(0xFF707070),
                          ),
                          children: <TextSpan>[
                            TextSpan(
                                text:
                                    "This is how we communicate with you with less time-sensitive information"
                                        .tr()),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 50,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 32.0, right: 24.0, left: 24.0),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              shape: BoxShape.rectangle,
                              border: Border.all(color: Colors.grey.shade200)),
                          child: TextFormField(
                            controller: emailController,
                            textAlignVertical: TextAlignVertical.center,
                            textInputAction: TextInputAction.next,
                            style: TextStyle(fontSize: 18.0),
                            onSaved: (val) => _phoneNumber = val,
                            keyboardType: TextInputType.emailAddress,
                            cursorColor: Color(COLOR_PRIMARY),
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              contentPadding:
                                  EdgeInsets.only(left: 16, right: 16),
                              hintText: 'name@abc.com'.tr(),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                      color: Color(COLOR_PRIMARY), width: 2.0)),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.grey.shade200),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(40, 0, 40, 50),
        child:
            Text(
              "Check your index of verify your email\naddress. Your email will never be shared."
                  .tr(),
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xff525354),
                  fontWeight: FontWeight.normal,
                  fontSize: 15.0),
              textAlign: TextAlign.center,
            ),
      ),
      appBar:PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () async {
                      String pattern =
                          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
                      RegExp regex = RegExp(pattern);
                      if (!regex.hasMatch(emailController.text)) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Enter valid email.'.tr()),
                          duration: Duration(seconds: 6),
                        ));
                      } else { bool? user = await FireStoreUtils.getEmail(emailController.text);
    if(user!){
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text('Email address already exist try with different email address.'.tr())));
    }else {
                        setSetQuestionPreferences("email", emailController.text);
                        var rnd =  Random();
                        var next = rnd.nextDouble() * 1000000;
                        while (next < 100000) {
                          next *= 10;
                        }
                        sendEmail("OTP :"+(next.toInt()).toString());
                        push(context, OnBoardingQuestionFifteenScreen(next.toInt()));
                       // push(context, OnBoardingQuestionEndScreen());
                          }
                      }
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [/* Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> setSetQuestionPreferences(String key, String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }

  Future sendEmail( String message) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var first_name=prefs.getString("first_name") ?? '';
    String email= emailController.text;
    final url = Uri.parse('https://api.emailjs.com/api/v1.0/email/send');
    const serviceId = EMAILJSSERVICEID;
    const templateId = EMAILJSTEMPLATE;
    const userId = EMAILJSUSERID;
    final response = await http.post(url,
        headers: {
      'origin':'http://localhost',
      'Content-Type': 'application/json'},//This line makes sure it works for all platforms.
        body: json.encode({
          'service_id': serviceId,
          'template_id': templateId,
          'user_id': userId,
          'template_params': {
            'to_name': first_name,
            'to_email':email,
            'message': message
          }
        }));
    return response.statusCode;
  }
}
