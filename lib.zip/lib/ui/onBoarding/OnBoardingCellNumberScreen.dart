import 'dart:io';

import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/model/User.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingOtpVerficationScreen.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionsOneScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnBoardingCellNumberScreen extends StatefulWidget {
  const OnBoardingCellNumberScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingCellNumberScreenState createState() =>
      _OnBoardingCellNumberScreenState();
}

class _OnBoardingCellNumberScreenState
    extends State<OnBoardingCellNumberScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String? _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  final numberController = TextEditingController();
  PhoneNumber? phone;

  @override
  void initState() {
    super.initState();
    if (numberController.text.length == 10) {
      print(numberController.text.length.toString());
      FocusScope.of(context).requestFocus(FocusNode());
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 30,
                ),

                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(
                      'Enter Your Cell Number'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(

                        color: Color(0xFF0573ac),
                        fontWeight: FontWeight.bold,
                        fontSize: _large! ? 32 : (_medium! ? 30 : 20),
                      ),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 10, right: 0, bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "We'll send a unique code to register quickly".tr(),
                        textScaleFactor: 1.0,
                        style:
                            TextStyle(color: Color(0xFF707070), fontSize: 22.0),
                        textAlign: TextAlign.start,
                      ),
                      SizedBox(
                        height: 50,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 32.0, right: 8.0, left: 8.0),
                        child: Container(
                          color: Colors.white,
                          /*decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              shape: BoxShape.rectangle,
                              border: Border.all(color: Colors.grey.shade200)),*/

                          child: IntlPhoneField(
                            decoration: InputDecoration(
                              labelText: 'Cell Number'.tr(),
                              border: OutlineInputBorder(
                                borderSide: BorderSide(),
                              ),
                            ),
                            initialCountryCode: 'US',
                            onChanged: (pho) {
                              if (pho.number.length == 10) {
                                FocusScope.of(context)
                                    .requestFocus(FocusNode());
                              }
                              phone = pho;
                            },
                          ), /* InternationalPhoneNumberInput(
                              textStyle: TextStyle(color: Colors.black),
                              onInputChanged: (PhoneNumber number) {
                                if (number.phoneNumber?.length == 12) {
                                  FocusScope.of(context).requestFocus(FocusNode());
                                }
                                _phoneNumber = number.phoneNumber;
                              },onInputValidated: (bool value) {
                                _isPhoneValid = value;
                              } ,
                              ignoreBlank: true,
                              selectorTextStyle: TextStyle(color: Colors.black),
                              autoValidateMode: AutovalidateMode.onUserInteraction,
                              inputDecoration: InputDecoration(
                                hoverColor:  Colors.black,
                                hintText: 'Cell Number'.tr(),
                                hintStyle: TextStyle(color: Colors.black),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                ),
                                isDense: true,
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                ),
                              ),
                              inputBorder: OutlineInputBorder(
                                borderSide: BorderSide.none,
                              ),
                              initialValue: PhoneNumber(isoCode: 'US'),
                              selectorConfig: SelectorConfig(
                                  selectorType: PhoneInputSelectorType.DIALOG),
                            ),
                          )*/ /*TextFormField(
                            textAlignVertical: TextAlignVertical.center,
                            textInputAction: TextInputAction.next,
                            style: TextStyle(fontSize: 18.0),
                            controller: numberController,
                            onChanged: (c) {
                              print(numberController.text.length.toString());
                              if (numberController.text.length == 10) {
                                FocusScope.of(context)
                                    .requestFocus(FocusNode());
                              }
                            },
                            onSaved: (val) => _phoneNumber = val,
                            keyboardType: TextInputType.phone,
                            cursorColor: Color(COLOR_PRIMARY),
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              contentPadding:
                                  EdgeInsets.only(left: 16, right: 16),
                              hintText: '(xxx) xxx-xxxx'.tr(),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                      color: Color(COLOR_PRIMARY), width: 2.0)),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.grey.shade200),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                          ),*/
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(40, 0, 40, 50),
        child: Text(
          "Great news - no password required.".tr(),
          textScaleFactor: 1.0,
          style: TextStyle(
              color: Color(0xff525354),
              fontWeight: FontWeight.normal,
              fontSize: 15.0),
          textAlign: TextAlign.center,
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 00),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text(
                          "Back",
                          style: TextStyle(fontSize: 20),
                        ),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () async {
                      /* if (numberController.text.length < 10) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Enter Cell Number.'.tr()),
                          duration: Duration(seconds: 6),
                        ));
                      } else {*/
                      /*if (_key.currentState?.validate() ?? false) {
                          _key.currentState!.save();
                          if (_isPhoneValid) {
                            //await _submitPhoneNumber(_phoneNumber!);
                            setSetQuestionPreferences(
                                "cell_number", _phoneNumber!);
                            push(context, OnBoardingOtpVerficationScreen(
                                _phoneNumber!));
                          }
                        else
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: Text('Invalid phone number, '
                                  'Please try again with a different phone number.'
                                  .tr())));
                      } else {
                      setState(() {
                      _validate = AutovalidateMode.onUserInteraction;
                      });
                      }*/

                      //  }
                      if (phone != null) {
                        if (phone!.number.length >= 10) {
                          //await _submitPhoneNumber(_phoneNumber!);
                          bool? user = await FireStoreUtils.getCellNumber(
                              (phone!.countryCode + phone!.number));
                          if (user!) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text(
                                    'Cell number already exist try with different cell number'
                                        .tr())));
                          } else {
                            setSetQuestionPreferences("cell_number",
                                phone!.countryCode + phone!.number);
                            push(
                                context,
                                OnBoardingOtpVerficationScreen(
                                    phone!.countryCode + phone!.number));
                          //  push(context, OnBoardingQuestionOneScreen());
                          }
                        } else
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: Text('Enter cell number '.tr())));
                      } else
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Enter cell number '.tr())));
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        /*Text(
                          "Next",
                          style: TextStyle(fontSize: 20),
                        ),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> setSetQuestionPreferences(String key, String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
