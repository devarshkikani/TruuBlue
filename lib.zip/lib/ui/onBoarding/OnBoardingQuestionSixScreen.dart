import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionSevanScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants.dart';

class OnBoardingQuestionSixScreen extends StatefulWidget {
  const OnBoardingQuestionSixScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionSixScreenState createState() => _OnBoardingQuestionSixScreenState();
}

class _OnBoardingQuestionSixScreenState extends State<OnBoardingQuestionSixScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String?  _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  bool checkBoxOne = false;
  bool checkBoxTwo = false;
  bool checkBoxThree = false;
  bool checkBoxFour = false;
  bool checkBoxFive = false;
  bool checkBoxSix = false;
  int SelectedIndex=-1;
  String? selection;

  int SelectedIndexOne=-1;
  String? selectionOne;

  final List<String> _SexualityList = [
    'Straight'.tr(),
    'Gay'.tr(),
    'Lesbian'.tr(),
    'Bisexual'.tr(),
    'Demisexual'.tr(),
    'Pansexual'.tr(),
    'Queer'.tr(),
    'Questioning'.tr(),
    'Prefer Not to Say'.tr(),
  ];

  final List<String> _SexualityListOne = [
    'Straight'.tr(),
    'Gay'.tr(),
    'Lesbian'.tr(),
    'Bisexual'.tr(),
    'Demisexual'.tr(),
    'Pansexual'.tr(),
    'Queer'.tr(),
    'Questioning'.tr(),
    'Prefer Not to Say'.tr(),
  ];

  final Map<String,bool> _SexualityMAp = {
    'Straight'.tr():false,
    'Gay'.tr():false,
    'Lesbian'.tr():false,
    'Bisexual'.tr():false,
    'Demisexual'.tr():false,
    'Pansexual'.tr():false,
    'Queer'.tr():false,
    'Questioning'.tr():false,
    'Prefer Not to Say'.tr():false,
  };

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
                children: <Widget>[
                  SizedBox(
                    height: 30,
                  ),
                  Align(
                      alignment: Directionality.of(context) == TextDirection.ltr
                          ? Alignment.topLeft
                          : Alignment.topLeft,
                      child: Text(
                        'What is your sexuality?'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                          color: Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                        textAlign: TextAlign.start,
                      )),
                  SizedBox(
                    height: 20,
                  ),
                  /*Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value: checkBoxOne,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxOne = newValue!;
                                      checkBoxTwo = false;
                                      checkBoxThree=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Straight',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value: checkBoxTwo,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxTwo = newValue!;
                                      checkBoxOne=false;
                                      checkBoxThree=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Gay',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value:  checkBoxThree,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxThree = newValue!;
                                      checkBoxOne=false;
                                      checkBoxTwo=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Lesbian',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                    ],
                  ),*/
                  Container(

                    child: GridView.builder(

                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount: _SexualityList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return _PreferPronounItem(
                              _SexualityList[index],index);
                        }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(childAspectRatio:4.5,
                        crossAxisCount: 2 ),)
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Align(
                      alignment: Directionality.of(context) == TextDirection.ltr
                          ? Alignment.topLeft
                          : Alignment.topLeft,
                      child: Text(
                        'Who do you want to date?'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                          color: Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                        textAlign: TextAlign.start,
                      )),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                      child: GridView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount: _SexualityMAp.length,
                        itemBuilder: (BuildContext context, int index) {
                          return _WhoYItem(
                              _SexualityMAp.entries.elementAt(index).key,index);

                        }, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(childAspectRatio: 4.5,
                          crossAxisCount: 2 ),)
                  ),
                 /* Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value:  checkBoxFour,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxFour = newValue!;
                                      checkBoxFive=false;
                                      checkBoxSix=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Straight',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value: checkBoxFive,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxFive = newValue!;
                                      checkBoxFour=false;
                                      checkBoxSix=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Gay',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 20,
                            child: Transform.scale(
                              scale: 1.3,
                              child: Checkbox(value: checkBoxSix,
                                  activeColor: Color(0xFF66BB6A),
                                  onChanged:(bool? newValue){
                                    setState(() {
                                      checkBoxSix = newValue!;
                                      checkBoxFour=false;
                                      checkBoxFive=false;
                                    });
                                  }),
                            ),
                          ),
                          Text('Lesbian',style: TextStyle(fontSize: 12),),
                        ],
                      ),
                    ],
                  )*/
                ]
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(40,0,40,50),
        child:
            Text(
              "You can change these settings later.".tr(),
              textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xff525354),
                  fontWeight: FontWeight.normal,
                  fontSize: 15.0),
              textAlign: TextAlign.center,
            ),
      ),
      appBar:PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,50,20,0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                       /* Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
    if(selection==null ){
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text('Please select what is your sexuality.'.tr()),
    duration: Duration(seconds: 6),
    ));
    }else if(selectionOne==null ){
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text('Please select who do you want to date.'.tr()),
    duration: Duration(seconds: 6),
    ));
    }else {
      var yourgen = "Straight";
      if (checkBoxOne) {
        yourgen = "Straight";
      } else if (checkBoxTwo) {
        yourgen = "Gay";
      } else if (checkBoxThree) {
        yourgen = "Lesbian";
      }
      var wantto = "Straight";
      if (checkBoxFour) {
        wantto = "Straight";
      } else if (checkBoxFive) {
        wantto = "Gay";
      } else if (checkBoxSix) {
        wantto = "Lesbian";
      }
      String whowant="";
      _SexualityMAp.forEach((key, value) {
        if(value){
          if(whowant==""){
            whowant=key;
          }else{
            whowant=whowant+","+key;
          }
        }
      });
      setSetQuestionPreferences("Your_Sexuality", selection!);
      setSetQuestionPreferences("Want_Date_Sexuality", whowant);
      push(context, OnBoardingQuestionSevanScreen());
    }
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _PreferPronounItem(String _list,int index) {
    return Container(
      color: Colors.white,
      child: Padding(
          padding: const EdgeInsets.only(left: 0, top:0, right: 0, bottom: 0),
          child:Column(
            children: [
              InkWell(
                child: Padding(
                  padding: const EdgeInsets.only(left: 0, top:5, right: 0, bottom: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                        child: Transform.scale(
                          scale: 1.3,
                          child: Checkbox(value: SelectedIndex==index,
                              activeColor: Color(0xFF66BB6A),
                              onChanged:(bool? newValue){
                                setState(() {
                                  SelectedIndex=index;
                                  selection=_list;
                                });
                              }),
                        ),
                      ),
                      /*Visibility(
                        visible:SelectedIndex==index,child: Icon(Icons.check,color: Colors.blue,)),*/
                      Padding(
                        padding: const EdgeInsets.only(top: 0,bottom: 0),
                        child: Text(
                          _list.tr(),
                          textScaleFactor: 1.0,
                          style: TextStyle(fontSize: 12,color: Colors.black),
                        ),
                      ),

                    ],
                  ),
                ),
                onTap: (){
                  setState(() {
                    /* SelectedIndex=index;
                Cache().setPreferPronoun(_list);
                selection=_list;*/
                  });
                },
              ),
              //Divider(color: Colors.grey,height: 1,)
            ],
          )),
    );
  }
  _WhoYItem(String _list,int index) {
    return Container(
      color: Colors.white,
      child: Padding(
          padding: const EdgeInsets.only(left: 0, top:0, right: 0, bottom: 0),
          child:Column(
            children: [
              InkWell(
                child: Padding(
                  padding: const EdgeInsets.only(left: 0, top:5, right: 0, bottom: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                        child: Transform.scale(
                          scale: 1.3,
                          child: Checkbox(value:_SexualityMAp.entries.elementAt(index).value,
                              activeColor: Color(0xFF66BB6A),
                              onChanged:(bool? newValue){
                                setState(() {
                                  _SexualityMAp[_list]=newValue!;
                                  SelectedIndexOne=index;
                                  selectionOne=_list;
                                });
                              }),
                        ),
                      ),
                      /*Visibility(
                        visible:SelectedIndex==index,child: Icon(Icons.check,color: Colors.blue,)),*/
                      Padding(
                        padding: const EdgeInsets.only(top: 0,bottom: 0),
                        child: Text(
                          _list.tr(),
                          textScaleFactor: 1.0,
                          style: TextStyle(fontSize: 12,color: Colors.black),
                        ),
                      ),

                    ],
                  ),
                ),
                onTap: (){
                  setState(() {
                    /* SelectedIndex=index;
                Cache().setPreferPronoun(_list);
                selection=_list;*/
                  });
                },
              ),
              //Divider(color: Colors.grey,height: 1,)
            ],
          )),
    );
  }
  Future<bool> setSetQuestionPreferences(String key,String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
