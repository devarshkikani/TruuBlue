import 'package:dating/Cache.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionThreeScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

import '../../constants.dart';

class OnBoardingQuestionTwoScreen extends StatefulWidget {
  const OnBoardingQuestionTwoScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionOneScreenState createState() => _OnBoardingQuestionOneScreenState();
}

class _OnBoardingQuestionOneScreenState extends State<OnBoardingQuestionTwoScreen> {
  double _OneSliderValue = 8;
  double _TwoSliderValue = 8;
  double _ThreeSliderValue = 8;
  String?  _phoneNumber;
  bool checkBoxOne = false;
  bool checkBoxTwo = false;
  bool checkBoxThree = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);

    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 20.0, right: 20, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 30,
                ),
                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20.0),
                      child: Text(

                        "Where do you stand on these issues?" .tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                          color: Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                        textAlign: TextAlign.start,
                      ),
                    )),
                SizedBox(
                  height: 10,
                ),
                Container(
                  color: Color(0xFFf3fbff),
                  child: Column(
                    children: [
                      Padding(
                        padding:
                        const EdgeInsets.only(left: 16, top: 12, right: 16, bottom: 8),
                        child: Text(
                          "Support Pro-Choice".tr(),
                          textScaleFactor: 1.0,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Color(0xFF707070),
                              fontWeight: FontWeight.bold,
                              fontSize: 18.0),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, top: 0, right: 10, bottom: 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Fully\nAgainst".tr(),
                              textScaleFactor: 1.0,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10.0),
                            ),Text(
                              "Against".tr(),
                              textScaleFactor: 1.0,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10.0),
                            ),
                            Text(
                              "Neutral".tr(),
                              textScaleFactor: 1.0,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10.0),
                            ),
                            Text(
                              "Support".tr(),
                              textScaleFactor: 1.0,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10.0),
                            ),
                            Text(
                              "Fully\nSupport".tr(),
                              textScaleFactor: 1.0,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10.0),
                            ),
                          ],
                        ),
                      ),SfSlider(

                        value: _OneSliderValue,
                        max: 16,
                        interval: 4,
                        stepSize: 4,
                        showTicks: true,
                        thumbIcon:Container(
                          width: 10.0,
                          height: 10.0,
                          decoration: new BoxDecoration(
                            color: Color(COLOR_BLUE_BUTTON),
                            shape: BoxShape.circle,
                          ),
                        ) ,
                        activeColor: Colors.grey,
                        inactiveColor: Colors.grey,
                        onChanged: (dynamic value) {
                          setState(() {
                            _OneSliderValue = value;
                          });
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Deal Breaker :',
                            textScaleFactor: 1.0,style: TextStyle(fontSize: 12),),
                            SizedBox(
                              height: 20,
                              child: Transform.scale(
                                scale: 1.3,
                                child: Checkbox(value: checkBoxOne,
                                    activeColor: Color(0xFF66BB6A),
                                    onChanged:(bool? newValue){
                                      setState(() {
                                        checkBoxOne = newValue!;
                                      });
                                    }),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
            Container(
              color: Color(0xFFf3fbff),
              child: Column(
                children: [
                Padding(
                  padding:
                  const EdgeInsets.only(left: 16, top: 10, right: 16, bottom: 8),
                  child: Text(
                    "Better Climate Legislation".tr(),
                    textScaleFactor: 1.0,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(0xFF707070),
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 0, right: 10, bottom: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Fully\nAgainst".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),Text(
                        "Against".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Neutral".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Support".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Fully\nSupport".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                    ],
                  ),
                ),SfSlider(

                  value: _TwoSliderValue,
                  max: 16,
                  interval: 4,
                  stepSize: 4,
                  showTicks: true,
                  thumbIcon:Container(
                    width: 10.0,
                    height: 10.0,
                    decoration: new BoxDecoration(
                      color: Color(COLOR_BLUE_BUTTON),
                      shape: BoxShape.circle,
                    ),
                  ) ,
                  activeColor: Colors.grey,
                  inactiveColor: Colors.grey,
                  onChanged: (dynamic value) {
                    setState(() {
                      _TwoSliderValue = value;
                    });
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Deal Breaker :',textScaleFactor: 1.0,style: TextStyle(fontSize: 12),),
                      SizedBox(
                        height: 20,
                        child: Transform.scale(
                          scale: 1.3,
                          child: Checkbox(value: checkBoxTwo,
                              activeColor: Color(0xFF66BB6A),
                              onChanged:(bool? newValue){
                                setState(() {
                                  checkBoxTwo = newValue!;
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
                ),])),
            SizedBox(
              height: 10,
            ),
            Container(
              color: Color(0xFFf3fbff),
              child: Column(
                children: [
                Padding(
                  padding:
                  const EdgeInsets.only(left: 16, top: 10, right: 16, bottom: 8),
                  child: Text(
                    "Expand LGBTQ+ Rights".tr(),
                    textScaleFactor: 1.0,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(0xFF707070),
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, top: 0, right: 10, bottom: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Fully\nAgainst".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),Text(
                        "Against".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Neutral".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Support".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                      Text(
                        "Fully\nSupport".tr(),
                        textScaleFactor: 1.0,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 10.0),
                      ),
                    ],
                  ),
                ),SfSlider(

                  value: _ThreeSliderValue,
                  max: 16,
                  interval: 4,
                  stepSize: 4,
                  showTicks: true,
                  thumbIcon:Container(
                    width: 10.0,
                    height: 10.0,
                    decoration: new BoxDecoration(
                      color: Color(COLOR_BLUE_BUTTON),
                      shape: BoxShape.circle,
                    ),
                  ) ,
                  activeColor: Colors.grey,
                  inactiveColor: Colors.grey,
                  onChanged: (dynamic value) {
                    setState(() {
                      _ThreeSliderValue = value;
                    });
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Deal Breaker :',textScaleFactor: 1.0,style: TextStyle(fontSize: 12),),
                      SizedBox(
                        height: 20,
                        child: Transform.scale(
                          scale: 1.3,
                          child: Checkbox(value: checkBoxThree,
                              activeColor: Color(0xFF66BB6A),
                              onChanged:(bool? newValue){
                                setState(() {
                                  checkBoxThree = newValue!;
                                });
                              }),
                        ),
                      ),
                    ],
                  ),
                ),]))
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar:  Padding(
        padding: const EdgeInsets.fromLTRB(40,0,40,50),
        child:
            Text(
              "You will be able to change these settings later.".tr(),
    textScaleFactor: 1.0,
              style: TextStyle(
                  color: Color(0xff525354),
                  fontWeight: FontWeight.normal,
                  fontSize: 14.0),
              textAlign: TextAlign.center,
            ),
      ),
      appBar:PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,50,20,0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },

                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      // if(!checkBoxOne && !checkBoxTwo && !checkBoxThree){
                      //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      //     content: Text('Please select where do you stand on these issues'.tr()),
                      //     duration: Duration(seconds: 6),
                      //   ));
                      // }else{

                        setSetQuestionPreferences("Q1",getQuestion(_OneSliderValue));
                        setSetQuestionPreferences("Q2",getQuestion(_TwoSliderValue));
                        setSetQuestionPreferences("Q3",getQuestion(_ThreeSliderValue));
                        setSetQuestionPreferences("Q1_Deal_Breaker",!checkBoxOne?"0":"1");
                        setSetQuestionPreferences("Q2_Deal_Breaker",!checkBoxTwo?"0":"1");
                        setSetQuestionPreferences("Q3_Deal_Breaker",!checkBoxThree?"0":"1");
                        push(context, OnBoardingQuestionThreeScreen());
                     // }

                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
    return Scaffold(
      body:  Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 30,
          ),
          Center(
            child: Image.asset(
              'assets/images/logo_green.png',
              width: 200.0,
              height: 150.0,
              color: Color(COLOR_PRIMARY),
            ),
          ),
          Padding(
            padding:
            const EdgeInsets.only(left: 16, top: 32, right: 16, bottom: 8),
            child: Text(
              'Where do you stand on these issues?'.tr(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Color(COLOR_BLUE_BUTTON),
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding:
            const EdgeInsets.only(left: 16, top: 32, right: 16, bottom: 8),
            child: Text(
              "A Woman's Right to Choose?".tr(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 24.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, top: 0, right: 15, bottom: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Fully\nAgents".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Natural".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Fully\nSupport".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
              ],
            ),
          ),Slider(
            value: _OneSliderValue,
            max: 100,
            divisions: 2,
            thumbColor: Color(COLOR_BLUE_BUTTON),
            activeColor: Color(COLOR_PRIMARY),
            inactiveColor: Colors.grey,
            onChanged: (double value) {
              setState(() {
                _OneSliderValue = value;
              });
            },
          ),
          Padding(
            padding:
            const EdgeInsets.only(left: 16, top: 10, right: 16, bottom: 8),
            child: Text(
              "Climate Change Legislation".tr(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 24.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, top: 0, right: 15, bottom: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Fully\nAgents".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Natural".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Fully\nSupport".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
              ],
            ),
          ),Slider(
            value: _TwoSliderValue,
            max: 100,
            divisions: 2,
            thumbColor: Color(COLOR_BLUE_BUTTON),
            activeColor: Color(COLOR_PRIMARY),
            inactiveColor: Colors.grey,
            onChanged: (double value) {
              setState(() {
                _TwoSliderValue = value;
              });
            },
          ),
          Padding(
            padding:
            const EdgeInsets.only(left: 16, top: 10, right: 16, bottom: 8),
            child: Text(
              "LGBTQ+ Rights".tr(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 24.0),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, top: 0, right: 15, bottom: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Fully\nAgents".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Natural".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
                Text(
                  "Fully\nSupport".tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 12.0),
                ),
              ],
            ),
          ),Slider(
            value: _ThreeSliderValue,
            max: 100,
            divisions: 2,
            thumbColor: Color(COLOR_BLUE_BUTTON),
            activeColor: Color(COLOR_PRIMARY),
            inactiveColor: Colors.grey,
            onChanged: (double value) {
              setState(() {
                _ThreeSliderValue = value;
              });
            },
          ),
          Padding(
            padding: const EdgeInsets.only(right: 40.0, left: 40.0, top: 40),
            child: ConstrainedBox(
              constraints: const BoxConstraints(minWidth: double.infinity),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Color(COLOR_BLUE_BUTTON),
                  textStyle: TextStyle(color: Colors.white),
                  padding: EdgeInsets.only(top: 12, bottom: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25.0),
                      side: BorderSide(color: Color(COLOR_BLUE_BUTTON))),
                ),
                child: Text(
                  'Continue'.tr(),
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                onPressed: () {
                  Cache().setQuestionOne(getQuestion(_OneSliderValue));
                  Cache().setQuestionTwo(getQuestion(_TwoSliderValue));
                  Cache().setQuestionThree(getQuestion(_ThreeSliderValue));
                  setSetQuestionPreferences("Q1",getQuestion(_OneSliderValue));
                  setSetQuestionPreferences("Q2",getQuestion(_TwoSliderValue));
                  setSetQuestionPreferences("Q3",getQuestion(_ThreeSliderValue));
                  push(context,OnBoardingQuestionThreeScreen());
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  String getQuestion(double value){
    if(value==0){
      return "-2";
    }else if(value==4) {
      return "-1";
    }else if(value==8) {
      return "0";
    }else if(value==12) {
      return "1";
    }else{
      return "2";
    }
  }
  Future<bool> setSetQuestionPreferences(String key,String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
