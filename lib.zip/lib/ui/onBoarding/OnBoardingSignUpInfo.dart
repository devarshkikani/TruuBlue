
import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingCellNumberScreen.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionElevenScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class OnBoardingSignUpInfo extends StatefulWidget {
  const OnBoardingSignUpInfo({Key? key}) : super(key: key);

  @override
  _OnBoardingSignUpInfoState createState() => _OnBoardingSignUpInfoState();
}

class _OnBoardingSignUpInfoState extends State<OnBoardingSignUpInfo> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  Position? signUpLocation;

  @override
  void initState() {
    super.initState();
    getlocation().then((value) {
      if (value != null || signUpLocation != null) {
        getNotification();
      }
    });
    getNotification();
  }
  Future<Position?> getlocation() async {
    Future.delayed(const Duration(milliseconds: 500), () async {
      signUpLocation = await getCurrentLocation();

      setState(() {
        if (signUpLocation != null) {
          getNotification();
        }
      });
    });
    return signUpLocation;
  }

  getNotification() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
      setState(() {

      });
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');
      setState(() {

      });
    } else {
      print('User declined or has not accepted permission');
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 10,
                ),

                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.center,
                    child: Text(
                       'Create a New Account'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                          color: Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize: _large! ? 32 : (_medium! ? 30 : 23),),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 00, top: 10, right: 00, bottom: 8),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Please review the TruuBlue code of ethics'.tr(),
                        textScaleFactor: 1.0,
                        style: TextStyle(
                            color: Color(0xFF707070),
                            fontSize: 22),
                        textAlign: TextAlign.start,
                      ),SizedBox(
                        height: 30,
                      ),RichText(
                        textScaleFactor: 1.0,
                        text: new TextSpan(
                          // Note: Styles for TextSpans must be explicitly defined.
                          // Child text spans will inherit styles from parent
                          style: new TextStyle(
                            fontSize: 20.0,
                            color: Color(0xFF707070),
                          ),

                          children: <TextSpan>[
                            TextSpan(text: 'Be Honest - '.tr(), style: new
                            TextStyle(fontWeight: FontWeight.bold,color: Colors.black,fontSize: 18.0)),
                             TextSpan(text: 'Ensure that your bio, photos, and age are true and reflect who you really are'.tr(), style: new
                             TextStyle(fontSize: 18.0,color: Color(0xFF707070))),

                          ],
                        ),
                      ),SizedBox(
                        height: 20,
                      ),RichText(
                        textScaleFactor: 1.0,
                        text: new TextSpan(
                          // Note: Styles for TextSpans must be explicitly defined.
                          // Child text spans will inherit styles from parent
                          style: new TextStyle(
                            fontSize: 20.0,
                            color: Color(0xFF707070),
                          ),
                          children: <TextSpan>[
                            TextSpan(text: 'Be Safe - '.tr(), style: new TextStyle(fontWeight: FontWeight.bold,color: Colors.black,fontSize: 18.0)),
                            TextSpan(text: 'Make sure you are comfortable with a match before give out personal information'.tr(), style: new
                            TextStyle(fontSize: 18.0,color: Color(0xFF707070))),
                          ],
                        ),
                      ),SizedBox(
                        height: 20,
                      ),RichText(
                        textScaleFactor: 1.0,
                        text: new TextSpan(
                          // Note: Styles for TextSpans must be explicitly defined.
                          // Child text spans will inherit styles from parent
                          style: new TextStyle(
                            fontSize: 20.0,
                            color: Color(0xFF707070),
                          ),
                          children: <TextSpan>[
                            TextSpan(text: 'Be Respectful - '.tr(), style: new TextStyle(fontWeight: FontWeight.bold,color: Colors.black,fontSize: 18.0)),
                            TextSpan(text: 'Treat all members with the respect and dignity you would like in return'.tr(), style: new
                            TextStyle(fontSize: 18.0,color: Color(0xFF707070))),
                          ],
                        ),
                      ),SizedBox(
                        height: 20,
                      ),RichText(
                        textScaleFactor: 1.0,
                        text: new TextSpan(
                          // Note: Styles for TextSpans must be explicitly defined.
                          // Child text spans will inherit styles from parent
                          style: new TextStyle(
                            fontSize: 20.0,
                            color: Color(0xFF707070),
                          ),
                          children: <TextSpan>[
                            TextSpan(text: 'Be Diligent - '.tr(), style: new TextStyle(fontWeight: FontWeight.bold,color: Colors.black,fontSize: 18.0)),
                            TextSpan(text: 'Always report bad behavior immediately and help us maintain a safe environment'.tr(), style: new
                            TextStyle(fontSize: 18.0,color: Color(0xFF707070))),
                          ],
                        ),
                      )
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,50,20,0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              MaterialButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },

                textColor: Colors.green,
                child: Row(
                  children: [
                    Icon(
                      Icons.arrow_back_ios,
                      size: 30,
                      color: Color(0xFF0573ac),
                    ),
                    /*Text("Back",style: TextStyle(fontSize: 20),)*/
                  ],
                ),
                padding: EdgeInsets.all(10),
                shape: CircleBorder(),
              ),
      Center(
        child: Image.asset(
          'assets/images/truubluenew.png',
          width: 150.0,
          height: 50.0,
        ),
      ),
              MaterialButton(
                onPressed: () {
                  push(context, OnBoardingCellNumberScreen());//OnBoardingQuestionEndScreen
                },
                textColor: Colors.green,
                child: Row(
                  children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 30,
                      color: Color(0xFF0573ac),
                    ),
                  ],
                ),
                padding: EdgeInsets.all(10),
                shape: CircleBorder(),
              )
            ],
          ),
        ),
      ),
    );
  }
}
