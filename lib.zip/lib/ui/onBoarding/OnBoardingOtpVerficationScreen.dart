import 'dart:async';

import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/main.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionTwoScreen.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionsOneScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:easy_localization/easy_localization.dart' as easy;
import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class OnBoardingOtpVerficationScreen extends StatefulWidget {
  String? cellNumber;
   OnBoardingOtpVerficationScreen( this.cellNumber) ;

  @override
  _OnBoardingOtpVerficationScreenState createState() => _OnBoardingOtpVerficationScreenState();
}

class _OnBoardingOtpVerficationScreenState extends State<OnBoardingOtpVerficationScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String?  _phoneNumber,_verificationID;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  bool   _codeSent = false;
  Size? size;
  Position? signUpLocation;
  final numberController = TextEditingController();
  bool isLoading = false;

  String? verificationId;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  late AuthCredential _phoneAuthCredential;
  late String _verificationId;
  var resendFlag=false;
  var timerFlag=true;
  late Timer _timer;
  int _start = 60;
  String seconds="seconds";

  @override
  initState()  {
    super.initState();
    //phoneSignIn(phoneNumber: widget.cellNumber!);
    _submitPhoneNumber(widget.cellNumber!);
    startTimer();
  }
  void startTimer() {
    try {
      const oneSec = const Duration(seconds: 1);
      _timer = new Timer.periodic(
        oneSec,
            (Timer timer) {
          if (_start == 0) {
            setState(() {
              timer.cancel();
              seconds="second";
              resendFlag = true;
              timerFlag = false;
            });
          } else {
            setState(() {
              _start--;
            });
          }
        },
      );
    }catch(e){
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),

      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 30,
                ),

                Align(
                    alignment: Directionality.of(context) == TextDirection.ltr
                        ? Alignment.topLeft
                        : Alignment.topLeft,
                    child: Text(
                      'Enter The Code You Received'.tr(),
                      textScaleFactor: 1.0,
                      style: TextStyle(
                          color:  Color(0xFF0573ac),
                          fontWeight: FontWeight.bold,
                          fontSize:  _large! ? 32 : (_medium! ? 30 : 25),),
                      textAlign: TextAlign.start,
                    )),

                /// user profile picture,  this is visible until we verify the
                /// code in case of sign up with phone number
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 10, right: 0, bottom: 8),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "".tr(),
                        style: TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                            fontSize: 20.0),
                        textAlign: TextAlign.start,
                      ),SizedBox(
                        height: 50,
                      ),
                      Padding(
                        padding:
                        const EdgeInsets.only(top: 32.0, right: 24.0, left: 24.0),
                        child:Container(

                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              shape: BoxShape.rectangle,
                              border: Border.all(color: Colors.grey.shade200)),
                          child:  TextFormField(
                            textAlignVertical: TextAlignVertical.center,
                            textInputAction: TextInputAction.next,
                            style: TextStyle(fontSize: 18.0),
                            controller: numberController,
                            onChanged: (c) {
                              print(numberController.text.length.toString());
                              if (numberController.text.length == 6) {
                                FocusScope.of(context)
                                    .requestFocus(FocusNode());
                              }
                            },
                            onSaved: (val) => _phoneNumber = val,
                            keyboardType: TextInputType.phone,
                            cursorColor: Colors.grey.shade500,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(left: 16, right: 16),
                              hintText: '------'.tr(),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                      color: Colors.grey.shade500, width: 2.0)),
                              errorBorder: OutlineInputBorder(
                                borderSide:
                                BorderSide(color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide:
                                BorderSide(color: Theme.of(context).errorColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.grey.shade200),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
              Visibility(
                visible:resendFlag ,
                child: InkWell(
                  onTap: (){
                    _submitPhoneNumber(widget.cellNumber!);
                  },
                  child: RichText(
                    textScaleFactor: 1.0,
                    text: new TextSpan(
                      // Note: Styles for TextSpans must be explicitly defined.
                      // Child text spans will inherit styles from parent
                      style: new TextStyle(
                        fontSize: 15.0,
                        color: Color(0xFF707070),
                      ),
                      children: <TextSpan>[
                        TextSpan(text: 'Click '.tr()),
                        TextSpan(text: 'here'.tr(),style: new TextStyle(decoration: TextDecoration.underline,)),
                        TextSpan(text: ' if you did not receive a code.'.tr()),
                      ],
                    ),
                  ),
                ),
              ),
                Visibility(
                  visible:timerFlag ,
                  child: RichText(
                    textScaleFactor: 1.0,
                    text: new TextSpan(
                      // Note: Styles for TextSpans must be explicitly defined.
                      // Child text spans will inherit styles from parent
                      style: new TextStyle(
                        fontSize: 15.0,
                        color: Color(0xFF707070),
                      ),
                      children: <TextSpan>[
                        TextSpan(text: 'You should receive the OTP in '.tr()),
                        TextSpan(text: _start.toString()+" "+seconds.tr(), style: new TextStyle(color: Colors.redAccent)),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20,50,20,0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text("Back",style: TextStyle(fontSize: 20),),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),
                  Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      if(numberController.text.length<6){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Enter Code.'.tr()),
                          duration: Duration(seconds: 6),
                        ));
                      }else{
                        //push(context, OnBoardingQuestionOneScreen());
                        _submitOTP(numberController.text);
                      }

                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [ /*Text("Next",style: TextStyle(fontSize: 20),),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submitOTP(String smsCodes) {
    /// get the `smsCode` from the user


    /// when used different phoneNumber other than the current (running) device
    /// we need to use OTP to get `phoneAuthCredential` which is inturn used to signIn/login
    AuthCredential credential = PhoneAuthProvider.credential(verificationId: _verificationID!, smsCode: smsCodes);

    _login(credential);
  }

  Future<void> _login(AuthCredential credential) async {
    /// This method is used to login the user
    /// `AuthCredential`(`_phoneAuthCredential`) is needed for the signIn method
    /// After the signIn method from `AuthResult` we can get `FirebaserUser`(`_firebaseUser`)
    try {
      await FirebaseAuth.instance
          .signInWithCredential(credential)
          .then(( authRes) {
        push(context, OnBoardingQuestionOneScreen());
      }).catchError((e) {
        print(e);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Invalid OTP"),
          duration: Duration(seconds: 6),
        ));
      } );

    } catch (e) {
      print(e);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Invalid OTP"),
        duration: Duration(seconds: 6),
      ));
    }
  }

  _submitPhoneNumber(String phoneNumber) async {
    //send code
    await showProgress(context, 'Sending code...'.tr(), true);
    await FireStoreUtils.firebaseSubmitPhoneNumber(
      phoneNumber,
          (String verificationId) {
        if (mounted) {
          hideProgress();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Code verification timeout, request new code.'.tr(),
              ),
            ),
          );
          setState(() {
            _codeSent = false;
          });
        }
      },
          (String? verificationId, int? forceResendingToken) {
        if (mounted) {
          hideProgress();
          _verificationID = verificationId;
          setState(() {
            _codeSent = true;
          });
        }
      },
          (auth.FirebaseAuthException error) {
        if (mounted) {
          hideProgress();
          print('${error.message} ${error.stackTrace}');
          String message = 'An error has occurred, please try again.'.tr();
          switch (error.code) {
            case 'invalid-verification-code':
              message = 'Invalid code or has been expired.'.tr();
              break;
            case 'user-disabled':
              message = 'This user has been disabled.'.tr();
              break;
            default:
              message = 'An error has occurred, please try again.'.tr();
              break;
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                message,
              ),
            ),
          );
        }
      },
          (auth.PhoneAuthCredential credential) async {
        if (mounted) {

        }
      },
    );
  }

  Future<void> phoneSignIn({required String phoneNumber}) async {
    await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: _onVerificationCompleted,
        verificationFailed: _onVerificationFailed,
        codeSent: _onCodeSent,
        codeAutoRetrievalTimeout: _onCodeTimeout);
  }

  _onVerificationCompleted(PhoneAuthCredential authCredential) async {
    print("verification completed ${authCredential.smsCode}");
    User? user = FirebaseAuth.instance.currentUser;
    setState(() {
      this.numberController.text = authCredential.smsCode!;
    });
    if (authCredential.smsCode != null) {
      try{
        UserCredential credential =
        await user!.linkWithCredential(authCredential);
      }on FirebaseAuthException catch(e){
        if(e.code == 'provider-already-linked'){
          await _auth.signInWithCredential(authCredential);
        }
      }
      setState(() {
        isLoading = false;
      });

    }
  }

  _onVerificationFailed(FirebaseAuthException exception) {
    if (exception.code == 'invalid-phone-number') {
      showMessage("The phone number entered is invalid!");
    }
  }

  _onCodeSent(String verificationId, int? forceResendingToken) {
    this.verificationId = verificationId;
    print(forceResendingToken);
    print("code sent");
  }

  _onCodeTimeout(String timeout) {
    return null;
  }

  void showMessage(String errorMessage) {
    showDialog(
        context: context,
        builder: (BuildContext builderContext) {
          return AlertDialog(
            title: Text("Error"),
            content: Text(errorMessage),
            actions: [
              TextButton(
                child: Text("Ok"),
                onPressed: () async {
                  Navigator.of(builderContext).pop();
                },
              )
            ],
          );
        }).then((value) {
      setState(() {
        isLoading = false;
      });
    });
  }
}
