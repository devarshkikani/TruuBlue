import 'dart:io';

import 'package:dating/constants.dart';
import 'package:dating/help/responsive_ui.dart';
import 'package:dating/services/FirebaseHelper.dart';
import 'package:dating/services/helper.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionFifteenScreen.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionFourteenScreen.dart';
import 'package:dating/ui/onBoarding/OnBoardingQuestionTwelveScreen.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnBoardingQuestionElevenScreen extends StatefulWidget {
  const OnBoardingQuestionElevenScreen({Key? key}) : super(key: key);

  @override
  _OnBoardingQuestionElevenScreenState createState() =>
      _OnBoardingQuestionElevenScreenState();
}

class _OnBoardingQuestionElevenScreenState
    extends State<OnBoardingQuestionElevenScreen> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  String? _phoneNumber;
  bool _isPhoneValid = false;
  bool? _isLoading, _large, _medium;
  double? _pixelRatio, bottom1;
  Size? size;
  bool checkBoxValue = true;
  final ImagePicker _imagePicker = ImagePicker();
  String? _imageOne;
  String? _imageTwo;
  String? _imageThree;
  String? _imageFour;
  String? _imageFive;
  String? _imageSix;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    var scrWidth = MediaQuery.of(context).size.width;
    var scrHeight = MediaQuery.of(context).size.height;
    _pixelRatio = MediaQuery.of(context).devicePixelRatio;
    _large = ResponsiveWidget.isScreenLarge(scrWidth, _pixelRatio!);
    _medium = ResponsiveWidget.isScreenMedium(scrWidth, _pixelRatio!);
    return Scaffold(
      backgroundColor: Color(COLOR_PRIMARY),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(left: 40.0, right: 40, bottom: 16),
          child: Form(
            key: _key,
            autovalidateMode: _validate,
            child: Column(children: <Widget>[
              SizedBox(
                height: 30,
              ),
              Align(
                  alignment: Directionality.of(context) == TextDirection.ltr
                      ? Alignment.topLeft
                      : Alignment.topLeft,
                  child: Text(
                    'Add photos'.tr(),
                    textScaleFactor: 1.0,
                    style: TextStyle(

                      color: Color(0xFF0573ac),
                      fontWeight: FontWeight.bold,
                      fontSize: _large! ? 32 : (_medium! ? 30 : 25),
                    ),
                    textAlign: TextAlign.start,
                  )),
              SizedBox(
                height: 20,
              ),
              Text(
                "A minimum of three quality photos draws the most attention"
                    .tr(),
                textScaleFactor: 1.0,
                style: TextStyle(color: Color(0xFF707070), fontSize: 16.0),
                textAlign: TextAlign.start,
              ),
              SizedBox(
                height: 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    child: Center(
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Container(
                              color: Color(0xFF68ce09),
                              width: 100,
                              height: 80,
                            ),
                          ),
                          Positioned.fill(
                              child: Align(
                            child: Icon(
                              Icons.camera_alt,
                              color: Colors.white,
                              size: 30,
                            ),
                          )),
                          _imageOne == null
                              ? Container()
                              : ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Center(
                                      child: Image.file(
                                    File(_imageOne!),
                                    width: 100,
                                    height: 80,
                                    fit: BoxFit.cover,
                                  )))
                        ],
                      ),
                    ),
                    onTap: () {
                      _onCameraClick("One");
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: Container(
                            color: Color(0xFF68ce09),
                            width: 100,
                            height: 80,
                          ),
                        ),
                        Positioned.fill(
                            child: Align(
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 30,
                          ),
                        )),
                        _imageTwo == null
                            ? Container()
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Center(
                                    child: Image.file(
                                  File(_imageTwo!),
                                  width: 100,
                                  height: 80,
                                  fit: BoxFit.cover,
                                )))
                      ],
                    ),
                    onTap: () {
                      _onCameraClick("Two");
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: Container(
                            color: Color(0xFF68ce09),
                            width: 100,
                            height: 80,
                          ),
                        ),
                        Positioned.fill(
                            child: Align(
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 30,
                          ),
                        )),
                        _imageThree == null
                            ? Container()
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Center(
                                    child: Image.file(File(_imageThree!),
                                        width: 100,
                                        height: 80,
                                        fit: BoxFit.cover)))
                      ],
                    ),
                    onTap: () {
                      _onCameraClick("Three");
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    child: Center(
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10.0),
                            child: Container(
                              color: Color(0xFF68ce09),
                              width: 100,
                              height: 80,
                            ),
                          ),
                          Positioned.fill(
                              child: Align(
                            child: Icon(
                              Icons.camera_alt,
                              color: Colors.white,
                              size: 30,
                            ),
                          )),
                          _imageFour == null
                              ? Container()
                              : ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Center(
                                      child: Image.file(
                                    File(_imageFour!),
                                    width: 100,
                                    height: 80,
                                    fit: BoxFit.cover,
                                  )))
                        ],
                      ),
                    ),
                    onTap: () {
                      _onCameraClick("Four");
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: Container(
                            color: Color(0xFF68ce09),
                            width: 100,
                            height: 80,
                          ),
                        ),
                        Positioned.fill(
                            child: Align(
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 30,
                          ),
                        )),
                        _imageFive == null
                            ? Container()
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Center(
                                    child: Image.file(
                                  File(_imageFive!),
                                  width: 100,
                                  height: 80,
                                  fit: BoxFit.cover,
                                )))
                      ],
                    ),
                    onTap: () {
                      _onCameraClick("Five");
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  InkWell(
                    child: Stack(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: Container(
                            color: Color(0xFF68ce09),
                            width: 100,
                            height: 80,
                          ),
                        ),
                        Positioned.fill(
                            child: Align(
                          child: Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 30,
                          ),
                        )),
                        _imageSix == null
                            ? Container()
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Center(
                                    child: Image.file(File(_imageSix!),
                                        width: 100,
                                        height: 80,
                                        fit: BoxFit.cover)))
                      ],
                    ),
                    onTap: () {
                      _onCameraClick("Six");
                    },
                  ),
                ],
              ),
            ]),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(40, 0, 40, 50),
        child: Text(
          "Photos are shared with other members.\nYou can add and edit photos later."
              .tr(),
          textScaleFactor: 1.0,
          style: TextStyle(
              color: Color(0xff525354),
              fontWeight: FontWeight.normal,
              fontSize: 15.0),
          textAlign: TextAlign.center,
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  MaterialButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                        /*Text(
                          "Back",
                          style: TextStyle(fontSize: 20),
                        ),*/
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  ),Center(
                    child: Image.asset(
                      'assets/images/truubluenew.png',
                      width: 150.0,
                      height: 50.0,
                    ),
                  ),
                  MaterialButton(
                    onPressed: () {
                      setSetQuestionPreferences("imageOne", _imageOne!);
                      setSetQuestionPreferences("imageTwo", _imageTwo!);
                      setSetQuestionPreferences("imageThree", _imageThree!);
                      setSetQuestionPreferences("imageFour", _imageFour??"");
                      setSetQuestionPreferences("imageFive", _imageFive??"");
                      setSetQuestionPreferences("imageSix", _imageSix??"");
                      push(context, OnBoardingQuestionFourteenScreen());
                    },
                    textColor: Colors.green,
                    child: Row(
                      children: [
                       /* Text(
                          "Next",
                          style: TextStyle(fontSize: 20),
                        ),*/
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 30,
                          color: Color(0xFF0573ac),
                        ),
                      ],
                    ),
                    padding: EdgeInsets.all(10),
                    shape: CircleBorder(),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _onCameraClick(String one) {
    final action = CupertinoActionSheet(
      message: Text(
        'Add profile picture'.tr(),
        style: TextStyle(fontSize: 15.0),
      ),
      actions: <Widget>[
        CupertinoActionSheetAction(
          child: Text('Choose from gallery'.tr()),
          onPressed: () async {
            Navigator.pop(context);
            XFile? imagess =
                await _imagePicker.pickImage(source: ImageSource.gallery);
            if (imagess != null) {
              //await _imagePicked(File(imagess.path),one);
              if (one.toLowerCase() == "one") {
                _imageOne = imagess.path;
              } else if (one.toLowerCase() == "two") {
                _imageTwo = imagess.path;
              } else if (one.toLowerCase() == "three") {
                _imageThree = imagess.path;
              } else if (one.toLowerCase() == "four") {
                _imageFour = imagess.path;
              } else if (one.toLowerCase() == "five") {
                _imageFive = imagess.path;
              } else if (one.toLowerCase() == "six") {
                _imageSix = imagess.path;
              }
            }
            setState(() {});
          },
        ),
        CupertinoActionSheetAction(
          child: Text('Take a picture'.tr()),
          onPressed: () async {
            Navigator.pop(context);
            XFile? image =
                await _imagePicker.pickImage(source: ImageSource.camera);
            if (image != null) {
              //await _imagePicked(File(image.path),one);
              if (one.toLowerCase() == "one") {
                _imageOne = image.path;
              } else if (one.toLowerCase() == "two") {
                _imageTwo = image.path;
              } else if (one.toLowerCase() == "three") {
                _imageThree = image.path;
              } else if (one.toLowerCase() == "four") {
                _imageFour = image.path;
              } else if (one.toLowerCase() == "five") {
                _imageFive = image.path;
              } else if (one.toLowerCase() == "six") {
                _imageSix = image.path;
              }
            }
            setState(() {});
          },
        ),
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text('Cancel'.tr()),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );
    showCupertinoModalPopup(context: context, builder: (context) => action);
  }

  Future<void> _imagePicked(File image, String one) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    showProgress(context, 'Uploading image...'.tr(), false);
    if (one.toLowerCase() == "one") {
      _imageOne = await FireStoreUtils.uploadUserImageToFireStorage(
          image, prefs.getString("cell_number") ?? '' + one);
    } else if (one.toLowerCase() == "two") {
      _imageTwo = await FireStoreUtils.uploadUserImageToFireStorage(
          image, prefs.getString("cell_number") ?? '' + one);
    } else {
      _imageThree = await FireStoreUtils.uploadUserImageToFireStorage(
          image, prefs.getString("cell_number") ?? '' + one);
    }
    hideProgress();
  }

  Future<bool> setSetQuestionPreferences(String key, String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString(key, value);
  }
}
