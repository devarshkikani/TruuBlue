
class Cache{
   String _preferPronoun="";
   String _QuestipnOne="";
   String _QuestipnTwo="";
   String _QuestipnThree="";
   String _QuestipnFour="";
   String _QuestipnFive="";
   String _QuestipnSix="";

  setPreferPronoun(String preferPronoun){
    _preferPronoun=preferPronoun;
  }

  String getPeferPronoun(){
    return _preferPronoun;
  }

  setQuestionOne(String questionOne){
    _QuestipnOne=questionOne;
  }

   String getQuestionOne(){
     return _QuestipnOne;
   }

   setQuestionTwo(String questionTwo){
     _QuestipnTwo=questionTwo;
   }

   String getQuestionTwo(){
     return _QuestipnTwo;
   }

   setQuestionThree(String questionThree){
     _QuestipnThree=questionThree;
   }

   String getQuestionThree(){
     return _QuestipnThree;
   }

   setQuestionFour(String questionFour){
     _QuestipnFour=questionFour;
   }

   String getQuestionFour(){
     return _QuestipnFour;
   }
   setQuestionFive(String questionFive){
     _QuestipnFive=questionFive;
   }

   String getQuestionFive(){
     return _QuestipnFive;
   }

   setQuestionSix(String questionSix){
     _QuestipnSix=questionSix;
   }

   String getQuestionSix(){
     return _QuestipnSix;
   }
}