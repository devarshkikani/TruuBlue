library constants;

const FINISHED_ON_BOARDING = 'finishedOnBoarding';
const COLOR_ACCENT = 0xFF99ff33;
const COLOR_PRIMARY_DARK = 0xFF428302;
//const COLOR_PRIMARY = 0xFFe0edf4;
const COLOR_PRIMARY = 0xFFffffff;
const COLOR_BLUE_BUTTON= 0xFF0573ac;
const FACEBOOK_BUTTON_COLOR = 0xFF415893;
const USERS = 'users';
const SWIPES = 'swipes';
const REMOVE = 'remove_user';
const CHANNEL_PARTICIPATION = 'channel_participation';
const CHANNELS = 'channels';
const THREAD = 'thread';
const REPORTS = 'reports';
const SUBSCRIPTIONS = 'subscriptions';
const SECOND_MILLIS = 1000;
const MINUTE_MILLIS = 60 * SECOND_MILLIS;
const HOUR_MILLIS = 60 * MINUTE_MILLIS;
const SWIPE_COUNT = 'swipe_counts';
const MONTHLY_SUBSCRIPTION = 'io.instamobile.flutter.android.plan.monthly';
const YEARLY_SUBSCRIPTION = 'io.instamobile.flutter.android.plan.yearly';

const SERVER_KEY =
    'AAAACShqb10:APA91bHB6bbO_7K0PSwFhZy_VmR_5n38_W1z5E2fwXdO9DxkMdnN_neQJFOYzSiwIFX1XWby-TKKTy4JPFwgNzAUZ2WVJojOfg6tqKelOn2BxLnLcGZC4K8FBvcJC47jgxhbY453lCSn';

const DEFAULT_AVATAR_URL =
    'https://www.iosapptemplates.com/wp-content/uploads/2019/06/empty-avatar.jpg';

const EMAILJSSERVICEID="service_ynhu31t";
const EMAILJSTEMPLATE="template_n84bvqd";
const EMAILJSUSERID="MB2XkKLHw8fuS_sSX";
